-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-06-2024 a las 00:28:10
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ecomv0.1`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `street_address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `addresses`
--

INSERT INTO `addresses` (`id`, `order_id`, `first_name`, `last_name`, `phone`, `street_address`, `city`, `state`, `zip_code`, `created_at`, `updated_at`) VALUES
(6, 6, 'Armando', 'Buitrago', '3146533259', 'cll 205v 12-32', 'Florencia', 'Caquetá', '691003', '2024-06-16 02:43:35', '2024-06-16 02:43:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `companies`
--

INSERT INTO `companies` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'SONY', '2024-06-14 21:31:33', '2024-06-14 21:31:33'),
(2, 'MICROSOFT', '2024-06-14 21:31:52', '2024-06-14 21:31:52'),
(3, 'NINTENDO', '2024-06-14 21:39:31', '2024-06-14 21:39:31'),
(4, 'FUNKO', '2024-06-14 21:40:06', '2024-06-14 21:40:06'),
(5, 'JOYTOY', '2024-06-14 21:40:31', '2024-06-14 21:40:31'),
(6, 'NETFLIX', '2024-06-15 00:27:40', '2024-06-15 00:27:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `developers`
--

CREATE TABLE `developers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `developers`
--

INSERT INTO `developers` (`id`, `name`, `website`, `created_at`, `updated_at`) VALUES
(1, 'Motive', 'https://www.ea.com/ea-studios/motive', '2024-06-14 21:32:46', '2024-06-14 21:32:46'),
(2, 'Arrowhead Game Studios', 'https://www.arrowheadgamestudios.com/', '2024-06-14 21:33:03', '2024-06-14 21:33:03'),
(3, 'Vicarious Visions', 'https://careers.blizzard.com/global/en/albany', '2024-06-14 21:34:44', '2024-06-14 21:34:44'),
(4, 'Larian Studios', 'https://larian.com/', '2024-06-14 21:35:12', '2024-06-14 21:35:12'),
(5, 'CAPCOM Co., Ltd.', 'https://www.capcom.com/', '2024-06-15 01:58:35', '2024-06-15 01:58:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ecard_uses`
--

CREATE TABLE `ecard_uses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ecard_uses`
--

INSERT INTO `ecard_uses` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Suscripción', '2024-06-14 21:35:31', '2024-06-14 21:36:44'),
(2, 'Divisa Digital', '2024-06-14 21:36:20', '2024-06-14 21:36:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genres`
--

CREATE TABLE `genres` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `genres`
--

INSERT INTO `genres` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Acción', '2024-06-14 21:18:54', '2024-06-14 21:18:54'),
(2, 'Aventura', '2024-06-14 21:19:05', '2024-06-14 21:19:05'),
(3, 'Rol', '2024-06-14 21:20:53', '2024-06-14 21:20:53'),
(4, 'Estrategia', '2024-06-14 21:20:57', '2024-06-14 21:20:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `genre_product`
--

CREATE TABLE `genre_product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `genre_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `genre_product`
--

INSERT INTO `genre_product` (`id`, `product_id`, `genre_id`, `created_at`, `updated_at`) VALUES
(7, 3, 2, NULL, NULL),
(8, 3, 4, NULL, NULL),
(9, 3, 3, NULL, NULL),
(10, 4, 1, NULL, NULL),
(11, 4, 2, NULL, NULL),
(12, 5, 1, NULL, NULL),
(13, 6, 1, NULL, NULL),
(20, 18, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_05_20_152955_create_regions_table', 1),
(6, '2024_05_20_152956_create_developers_table', 1),
(7, '2024_05_20_152956_create_genres_table', 1),
(8, '2024_05_20_152956_create_platforms_table', 1),
(9, '2024_05_20_152957_create_publishers_table', 1),
(10, '2024_05_20_152958_create_companies_table', 1),
(11, '2024_05_20_152959_create_ecard_uses_table', 1),
(12, '2024_05_20_152959_create_product_phy_types_table', 1),
(13, '2024_05_20_153000_create_products_table', 1),
(14, '2024_05_20_153001_create_orders_table', 1),
(15, '2024_05_20_153001_create_product_attributes_table', 1),
(16, '2024_05_20_153001_create_wishlists_table', 1),
(17, '2024_05_20_153002_create_addresses_table', 1),
(18, '2024_05_20_153002_create_order_items_table', 1),
(19, '2024_06_03_144956_create_genre_product_pivot_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `grand_total` decimal(10,2) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `status` enum('pending','processing','completed','declined','canceled') NOT NULL DEFAULT 'pending',
  `currency` varchar(255) DEFAULT NULL,
  `shipping_amount` decimal(10,2) DEFAULT NULL,
  `shipping_method` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `grand_total`, `payment_method`, `payment_status`, `status`, `currency`, `shipping_amount`, `shipping_method`, `notes`, `created_at`, `updated_at`) VALUES
(6, 3, 140000.00, 'stripe', 'paid', 'pending', 'cop', 0.00, 'none', 'Order placed by Fernando', '2024-06-16 02:43:35', '2024-06-16 02:44:11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_amount` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `unit_amount`, `total_amount`, `created_at`, `updated_at`) VALUES
(9, 6, 18, 1, 140000.00, 140000.00, '2024-06-16 02:43:35', '2024-06-16 02:43:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `platforms`
--

CREATE TABLE `platforms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `platforms`
--

INSERT INTO `platforms` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'STEAM', '2024-06-14 21:24:18', '2024-06-14 21:24:18'),
(2, 'EPIC', '2024-06-14 21:24:34', '2024-06-14 21:24:34'),
(3, 'PS STORE', '2024-06-14 21:41:03', '2024-06-14 21:41:03'),
(4, 'XBOX STORE', '2024-06-14 21:41:13', '2024-06-14 21:41:13'),
(5, 'E-SHOP', '2024-06-14 21:41:19', '2024-06-14 21:41:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `product_type` enum('digital','physical','ecard') NOT NULL DEFAULT 'digital',
  `gametype` enum('base','edition','dlc') NOT NULL DEFAULT 'base',
  `parent_products_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `price` decimal(10,2) NOT NULL,
  `discount_price` decimal(10,2) DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT NULL,
  `in_stock` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `on_sale` tinyint(1) NOT NULL DEFAULT 0,
  `company_id` bigint(20) UNSIGNED DEFAULT NULL,
  `platform_id` bigint(20) UNSIGNED DEFAULT NULL,
  `publisher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `developer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `region_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ecard_use_id` bigint(20) UNSIGNED DEFAULT NULL,
  `product_phy_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `minimum_requirements` text DEFAULT NULL,
  `recommended_requirements` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `label`, `slug`, `product_type`, `gametype`, `parent_products_id`, `description`, `image_path`, `images`, `price`, `discount_price`, `discount_percentage`, `in_stock`, `is_active`, `is_featured`, `on_sale`, `company_id`, `platform_id`, `publisher_id`, `developer_id`, `region_id`, `ecard_use_id`, `product_phy_type_id`, `release_date`, `minimum_requirements`, `recommended_requirements`, `created_at`, `updated_at`) VALUES
(3, 'Baldur\'s Gate 3 PC STEAM', 'Baldur\'s Gate 3', 'baldurs-gate-3-pc-steam', 'digital', 'base', NULL, 'Reúne a tu grupo y regresa a los Reinos Olvidados en una historia de compañerismo, traición, sacrificio, supervivencia y la atracción de un poder absoluto.\n\nUnas misteriosas aptitudes empiezan a surgir en tu interior por obra de un parásito de los azotamentes que te han implantado en el cerebro. Resístete y vuelve a la oscuridad contra sí misma o abraza la corrupción y conviértete en el mal supremo.\n\nDe manos de los creadores de Divinity: Original Sin 2, llega un juego de rol para la nueva generación de consolas, ambientado en el mundo de Dungeons & Dragons.', 'images/01J0BXM35PG7YTT4Z4EZ6339GG.webp', '[\"images\\/01J0BZ3HJR35GEXVVVKW8C16G7.webp\",\"images\\/01J0BZ3HJX80SXGEYB8F7SN9ER.jpg\",\"images\\/01J0BZ3HK0EHX5FHKQGPKY3SQV.jpg\",\"images\\/01J0BZ3HK4TS5B4NBKTWRQGPGX.jpg\",\"images\\/01J0BZ3HK6VHHM0JJ1M0X1AEWC.jpg\",\"images\\/01J0BZ3HK94GQ7PSV111CD4BR2.jpg\",\"images\\/01J0BZ3HKCZE0WWXWBZEVTNZ8R.jpg\"]', 199000.00, 159200.00, 20.00, 1, 1, 1, 1, NULL, 1, 4, 4, 1, NULL, NULL, '2023-08-03', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Windows 10 64-bit\nProcesador: Intel I5 4690 / AMD FX 8350\nMemoria: 8 GB de RAM\nGráficos: Nvidia GTX 970 / RX 480 (4GB+ of VRAM)\nDirectX: Versión 11\nAlmacenamiento: 150 GB de espacio disponible\nNotas adicionales: SSD required', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Windows 10 64-bit\nProcesador: Intel i7 8700K / AMD r5 3600\nMemoria: 16 GB de RAM\nGráficos: Nvidia 2060 Super / RX 5700 XT (8GB+ of VRAM)\nDirectX: Versión 11\nAlmacenamiento: 150 GB de espacio disponible\nNotas adicionales: SSD required', '2024-06-14 22:44:44', '2024-06-14 23:15:46'),
(4, 'Dead Space PC STEAM', 'Dead Space', 'dead-space-pc-steam', 'digital', 'base', NULL, 'Vuelve Dead Space™, el clásico de terror, supervivencia y ciencia ficción, reconstruido completamente desde cero para ofrecer una experiencia más profunda e inmersiva. Este remake presenta una fidelidad visual asombrosa, un sonido ambiente lleno de suspense y mejoras en la jugabilidad, sin perder ni un ápice de la escalofriante visión del juego original.\n\nIsaac Clarke es un ingeniero cualquiera con la misión de reparar la descomunal nave extractora USG Ishimura, pero descubrirá que algo ha ido terriblemente mal. La tripulación de la nave ha sido asesinada y su querida compañera Nicole está perdida en algún lugar a bordo.\n\nSin nadie que lo acompañe y armado únicamente con sus herramientas y habilidades de ingeniería, Isaac tendrá que darse prisa para encontrar a Nicole mientras va desvelando el terrorífico misterio de lo sucedido a bordo del Ishimura. Atrapado con unas criaturas hostiles, los necromorfos, Isaac se enfrenta a una batalla por la supervivencia no solo contra los horrores de la nave, sino para evitar caer en la locura.', 'images/01J0C1G81HH2VKVQ587SHE71MB.jpg', '[\"images\\/01J0C1G81P0AEQYQ9JZ4QCNGS1.jpg\",\"images\\/01J0C1G81TVB4PYGRV2G16K0GE.jpg\",\"images\\/01J0C1G81YR8ZAANYQHRQRG7D3.jpg\",\"images\\/01J0C1G821X1HGDCJJKKQ6958P.jpg\",\"images\\/01J0C1MKMAA1VG33SD7DCGAM42.jpg\"]', 234000.00, 70200.00, 70.00, 1, 1, 1, 1, NULL, 1, 1, 1, 1, NULL, NULL, '2023-01-27', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Window 10 64-bit +\nProcesador: Ryzen 5 2600x, Core i5 8600\nMemoria: 16 GB de RAM\nGráficos: AMD RX 5700, GTX 1070\nDirectX: Versión 12\nRed: Conexión de banda ancha a Internet\nAlmacenamiento: 50 GB de espacio disponible\nNotas adicionales: 50GB SATA SSD', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Window 10 64-bit +\nProcesador: Ryzen 5 5600X,Core i5 11600K\nMemoria: 16 GB de RAM\nGráficos: Radeon RX 6700 XT, Geforce RTX 2070\nDirectX: Versión 12\nRed: Conexión de banda ancha a Internet\nAlmacenamiento: 50 GB de espacio disponible\nNotas adicionales: 50GB SSD PCIe compatible', '2024-06-14 23:52:32', '2024-06-14 23:54:55'),
(5, 'Crash Bandicoot™ N. Sane Trilogy PC STEAM', 'Crash Bandicoot™ N. Sane Trilogy', 'crash-bandicoot-n-sane-trilogy-pc-steam', 'digital', 'base', NULL, '¡Vuelve Crash Bandicoot™, tu marsupial favorito! Mejorado, embelesado y listo para bailar con la colección de juegos La trilogía. Ahora puedes disfrutar de Crash Bandicoot como nunca antes. Gira, salta, rompe, enfréntate a los épicos desafíos y vive las aventuras de los tres juegos con los que empezó todo: Crash Bandicoot™, Crash Bandicoot™ 2: Cortex Strikes Back y Crash Bandicoot™ 3: Warped. ¡Vuelve a vivir tus momentos favoritos de Crash con gráficos remasterizados y prepárate para disfrutar a tope!', 'images/01J0C2AXW9WPXTCRQZ1WAEPWDH.jpg', '[\"images\\/01J0C2AXWF7DFRFTP8QDTW0QFA.jpg\",\"images\\/01J0C2AXWKE5M52N8BQPSXS2SX.jpg\",\"images\\/01J0C2AXWR0D1GA7S83SCM0SRC.jpg\",\"images\\/01J0C2AXWV4F224ER7QMHQX2JQ.jpg\"]', 140000.00, 140000.00, NULL, 1, 1, 1, 1, NULL, 1, 3, 3, 1, NULL, NULL, '2018-06-29', 'SO *: Windows 7\nProcesador: Intel Core i5-750 @ 2.67GHz | AMD Phenom II X4 965 @ 3.4GHz\nMemoria: 8 GB de RAM\nGráficos: NVIDIA GeForce GTX 660 2GB | AMD Radeon HD 7850 2GB\nDirectX: Versión 9.0c\nAlmacenamiento: 30 GB de espacio disponible\nTarjeta de sonido: DirectX 9.0c Compatible\n* A partir del 1 de enero de 2024, el cliente de Steam solo será compatible con Windows 10 y versiones posteriores.', 'SIN REQUISITOS RECOMENDADOS', '2024-06-15 00:07:07', '2024-06-15 00:07:07'),
(6, 'HELLDIVERS™ 2 PC STEAM', 'HELLDIVERS™ 2', 'helldivers-2-pc-steam', 'digital', 'base', NULL, 'HELLDIVERS™ 2 es un juego de disparos por equipos en tercera persona en el que las fuerzas de élite de los Helldivers luchan por ganar un conflicto intergaláctico y liberar a la galaxia de las crecientes amenazas alienígenas. Desde una perspectiva en tercera persona, los jugadores utilizan diversas armas (pistolas, ametralladoras, lanzallamas) y estratagemas (torretas, ataques aéreos, etc.) para disparar y eliminar a las fuerzas enemigas. El combate incluye la sangre y el desmembramiento de las fuerzas alienígenas. También se pueden ver las salpicaduras de sangre y los desmembramientos de los jugadores que sean alcanzados por explosiones del entorno o por fuego amigo. Los campamentos enemigos y los entornos del campo de batalla tienen manchas de sangre y cadáveres desmembrados.', 'images/01J0C2X1FD6QJMFXGT9BCCY7N3.jpg', '[\"images\\/01J0C2X1FKDZ8VXHR4GN1WMZAM.jpg\",\"images\\/01J0C2X1FQZ9G8MZCDAA2A727W.jpg\",\"images\\/01J0C2X1FTBND99SG5FT2JZ3C1.jpg\",\"images\\/01J0C2X1FXFNMC9G2VDA8T05TC.jpg\"]', 150000.00, 105000.00, 30.00, 1, 1, 1, 1, NULL, 1, 2, 2, 1, NULL, NULL, '2024-02-08', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Windows 10\nProcesador: Intel Core i7-4790K or AMD Ryzen 5 1500X\nMemoria: 8 GB de RAM\nGráficos: NVIDIA GeForce GTX 1050 Ti or AMD Radeon RX 470\nAlmacenamiento: 100 GB de espacio disponible', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: Windows 10\nProcesador: Intel Core i7-9700K or AMD Ryzen 7 3700X\nMemoria: 16 GB de RAM\nGráficos: NVIDIA GeForce RTX 2060 or AMD Radeon RX 6600XT\nAlmacenamiento: 100 GB de espacio disponible\nNotas adicionales: SSD Recommended', '2024-06-15 00:17:00', '2024-06-16 02:46:08'),
(7, 'Suscripción Netflix - 1 mes ', 'NETFLIX - 1 MES', 'suscripcion-netflix-1-mes', 'ecard', 'base', NULL, 'Netflix, Inc. es una empresa de entretenimiento y una plataforma de streaming estadounidense. Ubicada en Los Gatos (California), la compañía fue fundada el 29 de agosto de 1997 y un año después comenzó su actividad, ofreciendo un servicio de alquiler de DVD a través del correo postal. Actualmente, Netflix participa en la producción de obras audiovisuales, desde la creación o adquisición del producto hasta su difusión mundial, esta targeta contiene 1 mes de Suscripción.', 'images/01J0C3ENHGP3YRYZ8FXF06SBXW.jpg', '[\"images\\/01J0C3ENHRC33FDE88RPB05CBZ.jpg\",\"images\\/01J0C3ENHYB7R4W1GYCGWBTHSF.webp\"]', 40000.00, 40000.00, NULL, 1, 1, 0, 1, 6, NULL, NULL, NULL, NULL, 1, NULL, '2024-02-23', NULL, NULL, '2024-06-15 00:26:38', '2024-06-15 00:28:01'),
(8, 'Suscripción XBOX GAME PASS - 1 MES', 'XBOX GAME PASS - 1 MES', 'suscripcion-xbox-game-pass-1-mes', 'ecard', 'base', NULL, '¿Qué es Xbox Game Pass? Por un módico precio mensual, puedes disfrutar de cientos de juegos para Xbox. Juega en consolas, PC, dispositivos móviles y mucho más en función del plan de Game Pass que elijas.', 'images/01J0C3WC6FVE51JQX7EBVSYJSJ.jpg', '[\"images\\/01J0C3WC6K61HJR9731W3WBZPY.webp\",\"images\\/01J0C3WC6PPAMBCEJ9BDRX1B54.png\"]', 25000.00, 25000.00, NULL, 1, 1, 0, 1, 2, NULL, NULL, NULL, NULL, 1, NULL, '2024-02-03', NULL, NULL, '2024-06-15 00:34:07', '2024-06-15 00:34:07'),
(9, 'Nintendo Switch™ with Neon Blue and Neon Red Joy‑Con™ ', 'Nintendo Switch™', 'nintendo-switch-with-neon-blue-and-neon-red-joycon', 'physical', 'base', NULL, 'Juega en casa o sobre la marcha con un sistema. El sistema Nintendo Switch™ está diseñado para ir donde quiera que lo hagas, transformándose instantáneamente de una consola doméstica que juegas en la televisión a un sistema portátil que puedes jugar en cualquier lugar. Así que tienes más tiempo para jugar los juegos que amas, como quieras.', 'images/01J0C5NC34BPYWJVAF5WTQKQH7.jpg', '[\"images\\/01J0C5NC39TX3M9NFQRJFSVJM6.jpg\",\"images\\/01J0C5NC3C3VZ9ZJK3784ARFQX.jpg\",\"images\\/01J0C5NC3GS95DF9Y7JSRKM0YR.jpg\"]', 1500000.00, 1500000.00, NULL, 1, 1, 0, 1, 3, NULL, NULL, NULL, NULL, NULL, 1, '2022-10-14', NULL, NULL, '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(10, 'PlayStation®5 console (slim) ', 'PlayStation®5', 'playstation5-console-slim', 'physical', 'base', NULL, 'La consola PS5 desata nuevas posibilidades de juego que nunca anticipaste. Experimenta una carga ultrarrápida con un SSD de ultra alta velocidad, una inmersión más profunda con soporte para retroalimentación háptica, disparadores adaptativos y audio 3D*, y una nueva generación de increíbles juegos de PlayStation Velocidad de rayo: aproveche la potencia de una CPU, GPU y SSD personalizadas con E/S integradas que reescriben las reglas de lo que una consola PlayStation puede hacer. Juegos impresionantes: maravíllate con gráficos increíbles y experimenta nuevas características de PS5. Juega un catálogo posterior de juegos de PS4 compatibles. Inmersión impresionante: descubre una experiencia de juego más profunda con soporte para retroalimentación háptica, disparadores adaptativos y tecnología de audio 3D. El soporte vertical se vende por separado. * Audio 3D a través de altavoces de TV integrados o auriculares estéreo analógicos/USB. Se requiere configuración y actualización de software del sistema más reciente.', 'images/01J0C67Y90AB4HRZ1Z22ZCR1BZ.jpg', '[\"images\\/01J0C67Y94617GYXSH7JY3HXZC.jpg\",\"images\\/01J0C67Y97GGW7G6MJHTNMHQB8.jpg\"]', 3000000.00, 3000000.00, NULL, 1, 1, 0, 1, 1, NULL, NULL, NULL, NULL, NULL, 1, '2023-12-10', NULL, NULL, '2024-06-15 01:15:23', '2024-06-15 01:15:23'),
(11, 'Microsoft Xbox Series S 1TB SSD Console Carbon Black', ' Xbox Series S 1TB SSD', 'microsoft-xbox-series-s-1tb-ssd-console-carbon-black', 'physical', 'base', NULL, 'Experimenta la velocidad y el rendimiento de próxima generación con Xbox Series S en negro carbón, con un SSD de 1 TB. Aprovecha al máximo cada minuto de juego con Quick Resume, tiempos de carga ultrarrápidos y jugabilidad de hasta 120 FPS, todo alimentado por Xbox Velocity Architecture. Disfruta de juegos digitales de cuatro generaciones de Xbox, con cientos de títulos optimizados que se ven y juegan mejor que nunca. Aprovecha al máximo tu Xbox Series S con Xbox Game Pass Ultimate (la membresía se vende por separado) y sé el primero en jugar nuevos juegos como Starfield y Forza Motorsport el primer día. Además, disfruta de cientos de juegos como Minecraft Legends, Halo Infinite y Forza Horizon 5 con amigos en consola, PC y nube. Con juegos agregados todo el tiempo, siempre hay algo nuevo que jugar.', 'images/01J0C6XAZ74Z17D0E8E0PTPHV6.jpg', '[\"images\\/01J0C6XAZCPNK66KSW841436EA.jpg\",\"images\\/01J0C6XAZF3BV9Z6FRVVMG2DW8.jpg\",\"images\\/01J0C6XAZJNBYPM2SRS8NPSV6N.jpg\",\"images\\/01J0C6XAZN2F5A6JNPK995NYKC.jpg\"]', 3000000.00, 3000000.00, NULL, 1, 1, 0, 1, 2, NULL, NULL, NULL, NULL, NULL, 1, '2023-05-11', NULL, NULL, '2024-06-15 01:27:04', '2024-06-15 01:27:04'),
(18, 'Resident Evil 2 PC STEAM', 'Resident Evil 2', 'resident-evil-2-pc-steam', 'digital', 'base', NULL, 'Vuelve Resident Evil 2, la obra maestra que definió un género, completamente renovado para una narrativa aún más intensa. Con el motor gráfico RE propietario de Capcom, Resident Evil 2 supone un nuevo enfoque de esta saga clásica del survival horror, con gráficos espectacularmente realistas, estremecedor sonido inmersivo, una nueva vista sobre el hombro y nuevos controles, además de modos de juego del título original.\nResident Evil 2 supone la vuelta de la acción clásica, la exploración tensa y las mecánicas de resolución de rompecabezas que definieron la serie. Los jugadores acompañarán al policía novato Leon S. Kennedy y a la estudiante universitaria Claire Redfield, que se ven atrapados en una apocalíptica epidemia en Racoon City que ha transformado a su población en zombis mortíferos. Ambos personajes tienen sus propias campañas jugables, lo que permite a los jugadores ver la historia desde dos puntos de vista. El destino de ambos personajes, favoritos de los fans, está en manos de los jugadores, que deberán hacerlos colaborar y llegar hasta el fondo de lo que se esconde tras este terrorífico ataque a la ciudad. ¿Lograrán sobrevivir?\n', 'images/01J0EXJKPS1TM5RSJ2DAEV18MV.webp', '[\"images\\/01J0EXJKPY3B259Y11CGADRWRN.jpg\",\"images\\/01J0EXJKQ2WS03C1RJJBET94TX.jpg\",\"images\\/01J0EXJKQ5K6PVDMBF2GARTYRT.jpg\",\"images\\/01J0EXJKQ878AQ7F49C8Z15ZTP.jpg\"]', 140000.00, 140000.00, NULL, 1, 1, 1, 1, NULL, 1, 5, 5, 1, NULL, NULL, '2019-01-24', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: WINDOWS® 10 (64-BIT Required)\nProcesador: Intel® Core™ i5-4460 or AMD FX™-6300 or better\nMemoria: 8 GB de RAM\nGráficos: NVIDIA® GeForce® GTX 960 or AMD Radeon™ RX 460\nDirectX: Versión 12\nAlmacenamiento: 26 GB de espacio disponible\n', 'Requiere un procesador y un sistema operativo de 64 bits\nSO: WINDOWS® 10 (64-BIT Required)\nProcesador: Intel® Core™ i7-3770 or AMD FX™-9590 or better\nMemoria: 8 GB de RAM\nGráficos: NVIDIA® GeForce® GTX 1060 or AMD Radeon™ RX 480 with 3GB VRAM\nDirectX: Versión 12\nAlmacenamiento: 26 GB de espacio disponible\nNotas adicionales: This game is expected to run at 1080p/60 FPS. An internet connection is required for product activation. (Network connectivity uses Steam® developed by Valve® Corporation.)\n', '2024-06-16 02:41:39', '2024-06-16 02:41:39');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_attributes`
--

CREATE TABLE `product_attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_key` varchar(255) NOT NULL,
  `attribute_value` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `product_attributes`
--

INSERT INTO `product_attributes` (`id`, `product_id`, `attribute_key`, `attribute_value`, `created_at`, `updated_at`) VALUES
(1, 9, ' Dimensiones del producto ', '8,27 x 3,98 x 10,2 pulgadas; 3,18 Libras ', '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(2, 9, 'Tipo de producto ', 'Accesorio', '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(3, 9, 'Idioma ', 'Inglés', '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(4, 9, 'Número de modelo del producto ', 'Nacional ', '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(5, 9, 'Pilas ', '3 Iones de litio necesaria(s), incluida(s) ', '2024-06-15 01:05:15', '2024-06-15 01:05:15'),
(6, 10, 'Número de modelo del producto ', 'CFI-2000 ', '2024-06-15 01:15:23', '2024-06-15 01:15:23'),
(7, 10, 'Fabricante', 'Sony', '2024-06-15 01:15:23', '2024-06-15 01:15:23'),
(8, 10, 'Pilas ', '1 Iones de litio necesaria(s), incluida(s) ', '2024-06-15 01:15:23', '2024-06-15 01:15:23'),
(9, 10, 'Dimensiones del producto ', '14 x 17 x 7 pulgadas; 10,6 Libras ', '2024-06-15 01:15:23', '2024-06-15 01:15:23'),
(10, 11, 'ASIN ', 'B0C7HKS2RF', '2024-06-15 01:27:04', '2024-06-15 01:27:04'),
(11, 11, ' Dimensiones del producto ', ' 11,5 x 14,17 x 5,04 pulgadas; 6,98 Libras ', '2024-06-15 01:27:04', '2024-06-15 01:27:04'),
(12, 11, 'Clasificado ', 'Everyone', '2024-06-15 01:27:04', '2024-06-15 01:27:04'),
(13, 11, 'Pilas ', ' 2 AA necesaria(s), incluida(s) ', '2024-06-15 01:27:04', '2024-06-15 01:27:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_phy_types`
--

CREATE TABLE `product_phy_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `product_phy_types`
--

INSERT INTO `product_phy_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Consolas', '2024-06-14 21:30:00', '2024-06-14 21:30:00'),
(2, 'Funko Pop', '2024-06-14 21:30:28', '2024-06-14 21:31:20'),
(3, 'Perifericos', '2024-06-14 21:30:46', '2024-06-14 21:30:46'),
(4, 'Coleccionables', '2024-06-14 21:30:53', '2024-06-14 21:30:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publishers`
--

CREATE TABLE `publishers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `publishers`
--

INSERT INTO `publishers` (`id`, `name`, `website`, `created_at`, `updated_at`) VALUES
(1, 'Electronic Arts', 'https://www.ea.com/es-es', '2024-06-14 21:25:39', '2024-06-14 21:25:39'),
(2, 'PlayStation Publishing LLC', 'https://www.playstation.com/en-us/', '2024-06-14 21:26:03', '2024-06-14 21:26:03'),
(3, 'Activision', 'https://www.activision.com/es/home', '2024-06-14 21:26:24', '2024-06-14 21:26:24'),
(4, 'Larian Studios', 'https://larian.com/', '2024-06-14 21:27:22', '2024-06-14 21:27:22'),
(5, 'CAPCOM Co., Ltd.', 'https://www.capcom.com/', '2024-06-15 01:58:58', '2024-06-15 01:58:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `regions`
--

CREATE TABLE `regions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `regions`
--

INSERT INTO `regions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'GLOBAL', '2024-06-14 21:29:09', '2024-06-14 21:29:09'),
(2, 'LATAM', '2024-06-14 21:29:14', '2024-06-14 21:29:14'),
(3, 'EU', '2024-06-14 21:29:20', '2024-06-14 21:29:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, '$2y$10$qL3AQMbL.BbqQdHmkiqA4e.mIpr5jIUkbekSkHrRi/NvIgGTyY24y', NULL, '2024-06-14 21:08:11', '2024-06-14 21:08:11'),
(2, 'Armando', 'armando@gmail.com', NULL, '$2y$10$9y5YrmU66SwwNeP0XeTkLunP0zjiwpiG6fWFLhxNBSGd6ung8ZmJq', NULL, '2024-06-14 23:27:16', '2024-06-14 23:27:16'),
(3, 'Fernando', 'fernando@gmail.com', NULL, '$2y$10$Ui0KfhDe46.gGAvMIHU.UOK1n3sU.9JJgqoEMVd0tAMopzVwjQpy2', '1T3WznX7Qv1br4Ofpz4t3sxv2MXBTuDSBhE69vF5pTiMwEieLyLpJTowPrd1', '2024-06-16 01:48:22', '2024-06-16 02:47:27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(3, 3, 6, '2024-06-16 02:15:32', '2024-06-16 02:15:32');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addresses_order_id_foreign` (`order_id`);

--
-- Indices de la tabla `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `developers`
--
ALTER TABLE `developers`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ecard_uses`
--
ALTER TABLE `ecard_uses`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indices de la tabla `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `genre_product`
--
ALTER TABLE `genre_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `genre_product_product_id_foreign` (`product_id`),
  ADD KEY `genre_product_genre_id_foreign` (`genre_id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indices de la tabla `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`);

--
-- Indices de la tabla `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indices de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indices de la tabla `platforms`
--
ALTER TABLE `platforms`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_parent_products_id_foreign` (`parent_products_id`),
  ADD KEY `products_company_id_foreign` (`company_id`),
  ADD KEY `products_platform_id_foreign` (`platform_id`),
  ADD KEY `products_publisher_id_foreign` (`publisher_id`),
  ADD KEY `products_developer_id_foreign` (`developer_id`),
  ADD KEY `products_region_id_foreign` (`region_id`),
  ADD KEY `products_ecard_use_id_foreign` (`ecard_use_id`),
  ADD KEY `products_product_phy_type_id_foreign` (`product_phy_type_id`);

--
-- Indices de la tabla `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_attributes_product_id_foreign` (`product_id`);

--
-- Indices de la tabla `product_phy_types`
--
ALTER TABLE `product_phy_types`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  ADD KEY `wishlists_product_id_foreign` (`product_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `developers`
--
ALTER TABLE `developers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `ecard_uses`
--
ALTER TABLE `ecard_uses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `genres`
--
ALTER TABLE `genres`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `genre_product`
--
ALTER TABLE `genre_product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `platforms`
--
ALTER TABLE `platforms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `product_attributes`
--
ALTER TABLE `product_attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `product_phy_types`
--
ALTER TABLE `product_phy_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `publishers`
--
ALTER TABLE `publishers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `regions`
--
ALTER TABLE `regions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `genre_product`
--
ALTER TABLE `genre_product`
  ADD CONSTRAINT `genre_product_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `genre_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_developer_id_foreign` FOREIGN KEY (`developer_id`) REFERENCES `developers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_ecard_use_id_foreign` FOREIGN KEY (`ecard_use_id`) REFERENCES `ecard_uses` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_parent_products_id_foreign` FOREIGN KEY (`parent_products_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_platform_id_foreign` FOREIGN KEY (`platform_id`) REFERENCES `platforms` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_product_phy_type_id_foreign` FOREIGN KEY (`product_phy_type_id`) REFERENCES `product_phy_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_publisher_id_foreign` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD CONSTRAINT `product_attributes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
