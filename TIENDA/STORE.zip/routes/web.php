<?php

use App\Http\Controllers\ProductController;
use App\Livewire\HomePage;
use App\Livewire\CartPage;
use App\Livewire\GamePage;
use Illuminate\Support\Facades\Route;
use App\Livewire\AdvancedSearch;
use App\Livewire\Auth\ForgotPassword;
use App\Livewire\Auth\LoginPage;
use App\Livewire\Auth\RegisterPage;
use App\Livewire\Auth\ResetPassword;
use App\Livewire\CancelPage;
use App\Livewire\CheckoutPage;
use App\Livewire\DigitalProductPage;
use App\Livewire\EcardProductPage;
use App\Livewire\MyOrderDetailPage;
use App\Livewire\MyOrdersPage;
use App\Livewire\PhysicalProductPage;
use App\Livewire\SuccessPage;
use App\Livewire\UserPage;
use App\Livewire\WishlistPage;

Route::get('/', HomePage::class);
Route::get('/cart', CartPage::class);
Route::get('/search', AdvancedSearch::class)->name('advanced.search');
Route::get('/product/physical/{slug}', PhysicalProductPage::class)->name('product.physical.show');
Route::get('/product/digital/{slug}', DigitalProductPage::class)->name('product.digital.show');
Route::get('/product/ecard/{slug}', EcardProductPage::class)->name('product.ecard.show');
Route::get('/product/{slug}', [ProductController::class, 'show'])->name('product.show');


Route::middleware('guest')->group(function () {
    Route::get('/login', LoginPage::class)->name('login');
    Route::get('/register', RegisterPage::class);
    Route::get('/forgot', ForgotPassword::class)->name('password.request');
    Route::get('/reset/{token}', ResetPassword::class)->name('password.reset');
});

Route::middleware('auth')->group(function () {
    Route::get('/logout', function () {
        auth()->logout();
        return redirect('/');
    });

    Route::get('/checkout', CheckoutPage::class)->name('checkout');
    Route::get('/success', SuccessPage::class)->name('success');
    Route::get('/order/cancel', CancelPage::class)->name('cancel');
    Route::get('/wishlist', WishlistPage::class)->name('wishlist');
    Route::get('/my-orders', MyOrdersPage::class)->name('my-orders.index');
    Route::get('/userpage', UserPage::class)->name('my-orders.index');
    Route::get('/my-orders/{order_id}', MyOrderDetailPage::class)->name('my-orders.show');
});
