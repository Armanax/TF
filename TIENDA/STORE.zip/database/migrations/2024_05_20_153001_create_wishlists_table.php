<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('wishlists', function (Blueprint $table) {
            $table->id();  // Clave primaria, autoincremental
            $table->foreignId('user_id');  // Clave foránea para la tabla de usuarios
            $table->foreignId('product_id');  // Clave foránea para la tabla de productos
            $table->timestamps();  // Marcas de tiempo para 'created_at' y 'updated_at'

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');  // Si se elimina un usuario, también se eliminan sus listas de deseos
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');  // Si se elimina un producto, también se eliminan de las listas de deseos

            // Asegurarse de que las combinaciones de usuario y producto sean únicas
            $table->unique(['user_id', 'product_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('wishlists');
    }
};
