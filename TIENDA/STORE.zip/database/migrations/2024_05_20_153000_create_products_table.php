<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('label');
            $table->string('slug')->unique();
            $table->enum('product_type', ['digital', 'physical', 'ecard'])->default('digital');
            $table->enum('gametype', ['base', 'edition', 'dlc'])->default('base');
            $table->foreignId('parent_products_id')->nullable()->constrained('products')->onDelete('set null');
            $table->text('description');
            $table->string('image_path');
            $table->json('images')->nullable();
            $table->decimal('price', 10, 2);
            $table->decimal('discount_price', 10, 2)->nullable();
            $table->decimal('discount_percentage', 5, 2)->nullable();
            $table->boolean('in_stock')->default(true);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->boolean('on_sale')->default(false);
            $table->foreignId('company_id')->nullable()->constrained('companies')->onDelete('set null');
            $table->foreignId('platform_id')->nullable()->constrained('platforms')->onDelete('set null');
            $table->foreignId('publisher_id')->nullable()->constrained('publishers')->onDelete('set null');
            $table->foreignId('developer_id')->nullable()->constrained('developers')->onDelete('set null');
            $table->foreignId('region_id')->nullable()->constrained('regions')->onDelete('set null');
            $table->foreignId('ecard_use_id')->nullable()->constrained('ecard_uses')->onDelete('set null');
            $table->foreignId('product_phy_type_id')->nullable()->constrained('product_phy_types')->onDelete('set null');
            $table->date('release_date')->nullable();
            $table->text('minimum_requirements')->nullable();
            $table->text('recommended_requirements')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');

        Schema::table('your_table_name', function (Blueprint $table) {
            $table->dropColumn('images');
        });
        
    }
};
