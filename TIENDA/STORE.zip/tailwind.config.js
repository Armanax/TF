/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
    'node_modules/preline/dist/*.js',
  ],
  theme: {
    extend: {
      backgroundImage: {
        'wallpaper': "url('https://c.wallhere.com/photos/47/0c/video_games_Portal_game_black_background-1353059.jpg!d')"
      }
    },
  },
  plugins: [
    require('preline/plugin'),
  ],
}

