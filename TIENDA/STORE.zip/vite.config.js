import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'public/css/reset.css',
                'public/css/navbar.css',
                'public/css/homepage.css',
                'public/css/myorders.css',
                'public/css/myorderdetail.css',
                'public/css/advancedsearch.css',
                'public/css/cart.css',
                'public/css/register.css',
                'public/css/login.css',
                'public/css/forgotpass.css',
                'public/css/checkout.css',
                'public/css/success.css',
                'public/css/cancel.css',
                'public/css/resetpage.css',
                'public/css/wish.css',
                'public/css/physical.css',
                'public/css/digiproduct.css',
                'public/css/ecard.css',
                'resources/js/app.js'
            ],
            refresh: true,
        }),
    ],
});
