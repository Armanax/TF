<?php

namespace App\Models;

use App\Mail\DiscountAlertMail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'label',
        'slug',
        'product_type',
        'gametype',
        'parent_products_id',
        'description',
        'image_path',
        'images',
        'price',
        'discount_price',
        'discount_percentage',
        'in_stock',
        'is_active',
        'is_featured',
        'on_sale',
        'genres_id',
        'company_id',
        'platform_id',
        'publisher_id',
        'developer_id',
        'region_id',
        'ecard_use_id',
        'product_phy_type_id',
        'release_date',
        'minimum_requirements',
        'recommended_requirements',
    ];

    protected $casts = [
        'images' => 'array'
    ];

    public static function boot()
    {
        parent::boot();

        static::created(function ($product) {
            if (request()->has('attributes')) {
                foreach (request()->input('attributes') as $attribute) {
                    $product->attributes()->create($attribute);
                }
            }
        });

        static::deleting(function ($product) {
            $product->deleteImages();
        });
    }

    protected static function booted()
    {
        static::updated(function ($product) {
            if ($product->wasChanged('discount_percentage') && $product->discount_percentage > 0) {
                $product->notifyUsersOfDiscount();
            }
        });
    }

    public function notifyUsersOfDiscount()
    {
        $wishlists = $this->wishlists;

        foreach ($wishlists as $wishlist) {
            $user = $wishlist->user;
            Mail::to($user->email)->send(new DiscountAlertMail([$this]));
        }
    }

    public function deleteImages()
    {
        if ($this->images) {
            foreach ($this->images as $image) {
                Storage::delete($image);
            }
        }
        if ($this->image_path) {
            Storage::delete($this->image_path);
        }
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function platform()
    {
        return $this->belongsTo(Platform::class);
    }

    public function publisher()
    {
        return $this->belongsTo(Publisher::class);
    }

    public function genres() 
    {
        return $this->belongsToMany(Genre::class, 'genre_product');       
    }

    public function developer()
    {
        return $this->belongsTo(Developer::class);
    }

    public function region()
    {
        return $this->belongsTo(Region::class);
    }

    public function ecardUse()
    {
        return $this->belongsTo(EcardUse::class);
    }

    public function productPhyType()
    {
        return $this->belongsTo(ProductPhyType::class);
    }

    public function attributes()
    {
        return $this->hasMany(ProductAttribute::class);
    }

    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function wishlists()
    {
        return $this->hasMany(Wishlist::class);
    }

    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function parentGame()
    {
        return $this->belongsTo(Product::class, 'parent_products_id');
    }

    public function relatedProducts()
    {
        return $this->hasMany(Product::class, 'parent_products_id');
    }
}
