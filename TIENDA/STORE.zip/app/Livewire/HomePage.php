<?php

namespace App\Livewire;

use App\Helpers\GestionCarrito;
use App\Livewire\Partials\Navbar;
use Livewire\Component;
use App\Models\Product;
use App\Models\ProductPhyType;
use App\Models\Wishlist;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class HomePage extends Component
{

    use LivewireAlert;

    public $products;
    public $digitalProducts;
    public $PhysicalProducts;
    public $EcardProducts;
    public $featuredProducts;


    public function mount()
    {
        $this->products = Product::where('discount_percentage', '>', 0)
            ->orderBy('created_at', 'desc')
            ->take(6)
            ->get();

        $this->digitalProducts = Product::where('product_type', 'digital')
            ->orderBy('created_at', 'desc')
            ->take(6)
            ->get();

        $this->PhysicalProducts = Product::where('product_type', 'physical')
            ->orderBy('created_at', 'desc')
            ->take(6)
            ->get();
        
        $this->EcardProducts = Product::where('product_type', 'ecard')
            ->orderBy('created_at', 'desc')
            ->take(6)
            ->get();

        $this->featuredProducts = Product::where('is_featured', true)
            ->orderBy('created_at', 'desc')
            ->get();

        
    }

    private function formatNumber($number)
    {
        return number_format($number, 0, '', '');
    }

    //add item al carro 
    public function addToCart($product_id) {
        $total_count = GestionCarrito::añadirItem($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Producto añadido al carrito!', [
            'iconColor' => '#E9C500',
            'color' => '#ffffff',
            'background' => '#2c2827',
            'position' => 'bottom-end',
            'timer' => 3000,
            'toast' => true,
            'timerProgressBar' => false,
        ]);
    }

    public function toggleWishlist($productId)
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $wishlistItem = Wishlist::where('user_id', auth()->id())
                                    ->where('product_id', $productId)
                                    ->first();

        if ($wishlistItem) {
            $wishlistItem->delete();  
            $this->alert('info', 'Producto eliminado de la lista de deseos.', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        } else {
            Wishlist::create([
                'user_id' => auth()->id(),
                'product_id' => $productId
            ]);
            $this->alert('success', 'Producto añadido a la lista de deseos!', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        }


    }


    public function isProductInWishlist($productId)
    {
        return Wishlist::where('user_id', auth()->id())
                    ->where('product_id', $productId)
                    ->exists();
    }
    
    public function render()
    {
        $formattedProducts = $this->products->map(function ($product) {
            $product->discount_percentage = $this->formatNumber($product->discount_percentage);
            $product->price = $this->formatNumber($product->price);
            $product->discount_price = $this->formatNumber($product->discount_price);
            
            return $product;
        });

       

        

        return view('livewire.home-page', [
            'products' => $formattedProducts,
            
        ]);
    }
}
