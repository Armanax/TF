<?php

namespace App\Livewire;

use App\Helpers\GestionCarrito;
use App\Livewire\Partials\Navbar;
use Livewire\Component;
use App\Models\Product;
use App\Models\Wishlist;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class DigitalProductPage extends Component {

    use LivewireAlert;

    public $product;
    public $relatedProducts;

    public function mount($slug) { 
        $this->product = Product::with([
            'company', 'platform', 'publisher', 
            'developer', 'genres', 'region', 'relatedProducts'
        ])->where('slug', $slug)->firstOrFail(); 

        $this->relatedProducts = $this->product->relatedProducts;
    }

    //add item al carro 
    public function addToCart($product_id) {
        $total_count = GestionCarrito::añadirItem($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Producto añadido al carrito!', [
            'iconColor' => '#E9C500',
            'color' => '#ffffff',
            'background' => '#2c2827',
            'position' => 'bottom-end',
            'timer' => 3000,
            'toast' => true,
            'timerProgressBar' => false,
        ]);
    }

    public function toggleWishlist($productId)
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $wishlistItem = Wishlist::where('user_id', auth()->id())
                                    ->where('product_id', $productId)
                                    ->first();

        if ($wishlistItem) {
            $wishlistItem->delete();  // Elimina si ya existe
            $this->alert('info', 'Producto eliminado de la lista de deseos.', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        } else {
            Wishlist::create([
                'user_id' => auth()->id(),
                'product_id' => $productId
            ]);
            $this->alert('success', 'Producto añadido a la lista de deseos!', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        }


    }


    public function isProductInWishlist($productId)
    {
        return Wishlist::where('user_id', auth()->id())
                    ->where('product_id', $productId)
                    ->exists();
    }








    public function render()
    {
        return view('livewire.digital-product-page', [
            'product' => $this->product,
            'relatedProducts' => $this->relatedProducts,
        ]);
    }

    
}
