<?php

namespace App\Livewire;

use App\Helpers\GestionCarrito;
use App\Livewire\Partials\Navbar;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Carrito - Game Central')]
class CartPage extends Component{

    public $items_carrito = [];
    public $total_final;

    public function mount(){
        $this->items_carrito = GestionCarrito::obtenerCarrito();
        $this->total_final = GestionCarrito::calcularTotal($this->items_carrito);
    }

    public function quitarItem($product_id){
        $this->items_carrito = GestionCarrito::eliminarItem($product_id);
        $this->total_final = GestionCarrito::calcularTotal($this->items_carrito);
        $this->dispatch('update-cart-count', total_count: count($this->items_carrito))->to(Navbar::class);
    }

    public function AumentarItms($product_id){
        $this->items_carrito = GestionCarrito::aumentarCantidad($product_id);
        $this->total_final = GestionCarrito::calcularTotal($this->items_carrito);
    }

    public function ReducirItms($product_id){
        $this->items_carrito = GestionCarrito::disminuirCantidad($product_id);
        $this->total_final = GestionCarrito::calcularTotal($this->items_carrito);
    }

    public function checkout() {
        $this->items_carrito = GestionCarrito::actualizarPrecios();
        $this->total_final = GestionCarrito::calcularTotal($this->items_carrito);

        return redirect()->route('checkout');
    }

    

    public function render()
    {
        return view('livewire.cart-page');
    }

}
