<?php

namespace App\Livewire;

use App\Helpers\GestionCarrito;
use App\Livewire\Partials\Navbar;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Product;
use App\Models\Platform;
use App\Models\Genre;
use App\Models\Region;
use App\Models\Company;
use App\Models\EcardUse;
use App\Models\ProductPhyType;
use App\Models\Wishlist;
use Jantinnerezo\LivewireAlert\LivewireAlert;

class AdvancedSearch extends Component
{
    use LivewireAlert;
    use WithPagination;

    public $query;
    public $platform;
    public $genre = [];
    public $region;
    public $company;
    public $ecarduse;
    public $sortBy;
    public $minPrice;
    public $maxPrice;
    public $inStock = false;
    public $typeOfProduct;
    public $productType;


    public $platforms = [];
    public $genres = [];
    public $regions = [];
    public $companies = [];
    public $ecardUses = [];
    public $productPhyTypes = [];
    public $selectedGenres = [];

    protected $paginationTheme = 'bootstrap';

    protected $updatesQueryString = [
        'query' => ['except' => ''],
        'platform' => ['except' => ''],
        'genre' => ['except' => ''],
        'region' => ['except' => ''],
        'company' => ['except' => ''],
        'ecarduse' => ['except' => ''],
        'sortBy' => ['except' => ''],
        'minPrice' => ['except' => ''],
        'maxPrice' => ['except' => ''],
        'inStock' => ['except' => false],
        'typeOfProduct' => ['except' => ''],
    ];

    public function clearSelectedGenres()
    {
        $this->selectedGenres = [];
    }

    public function toggleGenre($genreId)
    {
        if (in_array($genreId, $this->selectedGenres)) {
            $this->selectedGenres = array_filter($this->selectedGenres, function($value) use ($genreId) {
                return $value != $genreId;
            });
        } else {
            $this->selectedGenres[] = $genreId;
        }
    }

    public function mount()
    {
        $this->platforms = Platform::all();
        $this->genres = Genre::all();
        $this->regions = Region::all();
        $this->companies = Company::all();
        $this->ecardUses = EcardUse::all();
        $this->productPhyTypes = ProductPhyType::all();
        $this->productType = request()->query('product_type', '');

        $this->query = request()->query('query', '');
    }

    public function updated()
    {
        $this->resetPage();
    }

    public function search()
    {
        $query = Product::query();

        if ($this->productType) {
            $query->where('product_type', $this->productType);
        }

        if (!empty($this->query)) {
            $query->where('name', 'LIKE', "%{$this->query}%");
        }

        if ($this->platform) {
            $query->where('platform_id', $this->platform);
        }

        // Usar selectedGenres en lugar de genre
        if (!empty($this->selectedGenres)) {
            $query->whereHas('genres', function ($q) {
                $q->whereIn('genres.id', $this->selectedGenres);
            });
        }

        if ($this->region) {
            $query->where('region_id', $this->region);
        }

        if ($this->company) {
            $query->where('company_id', $this->company);
        }

        if ($this->ecarduse) {
            $query->where('ecard_use_id', $this->ecarduse);
        }

        if ($this->minPrice) {
            $query->where('discount_price', '>=', $this->minPrice);
        }

        if ($this->maxPrice) {
            $query->where('discount_price', '<=', $this->maxPrice);
        }

        if ($this->inStock) {
            $query->where('in_stock', '>', 0);
        }

        if ($this->typeOfProduct) {
            if ($this->typeOfProduct === 'digital' || $this->typeOfProduct === 'physical' || $this->typeOfProduct === 'ecard') {
                $query->where('product_type', $this->typeOfProduct);
            } elseif (is_numeric($this->typeOfProduct)) {
                $query->where('product_phy_type_id', $this->typeOfProduct);
            }
        }

        if ($this->sortBy) {
            switch ($this->sortBy) {
                case 'Precio: Menor a Mayor':
                    $query->orderBy('discount_price', 'asc');
                    break;
                case 'Precio: Mayor a Menor':
                    $query->orderBy('discount_price', 'desc');
                    break;
                case 'Salida: Reciente':
                    $query->orderBy('release_date', 'desc');
                    break;
                case 'Salida: Antigua':
                    $query->orderBy('release_date', 'asc');
                    break;
            }
        }

        return $query->paginate(12);
    }

    public function searchGenre($searchTerm)
    {
        $this->genres = Genre::where('name', 'like', '%' . $searchTerm . '%')->get();
    }

    


    //add item al carro 
    public function addToCart($product_id) {
        $total_count = GestionCarrito::añadirItem($product_id);

        $this->dispatch('update-cart-count', total_count: $total_count)->to(Navbar::class);

        $this->alert('success', 'Producto añadido al carrito!', [
            'iconColor' => '#E9C500',
            'color' => '#ffffff',
            'background' => '#2c2827',
            'position' => 'bottom-end',
            'timer' => 3000,
            'toast' => true,
            'timerProgressBar' => false,
        ]);
    }

    public function toggleWishlist($productId)
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $wishlistItem = Wishlist::where('user_id', auth()->id())
                                    ->where('product_id', $productId)
                                    ->first();

        if ($wishlistItem) {
            $wishlistItem->delete();  // Elimina si ya existe
            $this->alert('info', 'Producto eliminado de la lista de deseos.', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        } else {
            Wishlist::create([
                'user_id' => auth()->id(),
                'product_id' => $productId
            ]);
            $this->alert('success', 'Producto añadido a la lista de deseos!', [
                'iconColor' => '#E9C500',
                'color' => '#ffffff',
                'background' => '#2c2827',
                'position' => 'bottom-end',
                'timer' => 3000,
                'toast' => true,
                'timerProgressBar' => false,
            ]);
        }


    }


    public function isProductInWishlist($productId)
    {
        return Wishlist::where('user_id', auth()->id())
                    ->where('product_id', $productId)
                    ->exists();
    }

    public function render()
    {
        return view('livewire.advanced-search', [
            'products' => $this->search(),
        ]);
    }
}
