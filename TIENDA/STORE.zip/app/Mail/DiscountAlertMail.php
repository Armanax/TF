<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

class DiscountAlertMail extends Mailable
{
    use Queueable, SerializesModels;

    public $products; // Ahora será un array de productos

    /**
     * Create a new message instance.
     *
     * @param array $products Datos de los productos para enviar en el correo
     */
    public function __construct(array $products)
    {
        $this->products = $products;
    }

    /**
     * Get the message envelope.
     *
     * @return Envelope
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Alertas de Descuentos - Game Central'
        );
    }

    /**
     * Get the message content definition.
     *
     * @return Content
     */
    public function content(): Content
    {
        return new Content(
            markdown: 'mail.discount.Alert',
            with: ['products' => $this->products]
        );
    }

    /**
     * Optionally define attachments for the message.
     *
     * @return array
     */
    public function attachments(): array
    {
        return [];
    }
}
