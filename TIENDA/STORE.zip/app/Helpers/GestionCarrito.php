<?php

namespace App\Helpers;

use App\Models\Product;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Storage;

class GestionCarrito {

    // Inicia la gestión del carrito recuperando el carrito existente de la cookie
    static public function obtenerCarrito() {
        return json_decode(Cookie::get('carrito'), true) ?? [];
    }

    // Encuentra un ítem específico en el carrito por su ID de producto
    static private function buscarIndiceItem($carrito, $product_id) {
        foreach ($carrito as $indice => $item) {
            if ($item['product_id'] == $product_id) {
                return $indice;
            }
        }
        return null;
    }

    // Añade un nuevo ítem al carrito si no existe previamente
    static private function añadirNuevoItem(&$carrito, $product_id) {
        $producto = Product::find($product_id, ['id', 'name', 'discount_price', 'image_path']);
        if ($producto) {
            $carrito[] = [
                'product_id'    => $product_id,
                'name'          => $producto->name,
                'image'         => Storage::url($producto->image_path),
                'quantity'      => 1,
                'unit_amount'   => $producto->discount_price,
                'total_amount'  => $producto->discount_price,
            ];
        }
    }

    // Actualiza el carrito guardándolo en una cookie
    static private function guardarCarrito($carrito) {
        Cookie::queue('carrito', json_encode($carrito), 15);
    }

    // Añade o actualiza la cantidad de un ítem en el carrito
    static public function añadirItem($product_id) {
        $carrito = self::obtenerCarrito();
        $indiceItem = self::buscarIndiceItem($carrito, $product_id);

        if (is_null($indiceItem)) {
            self::añadirNuevoItem($carrito, $product_id);
        } else {
            $carrito[$indiceItem]['quantity']++;
            $carrito[$indiceItem]['total_amount'] = $carrito[$indiceItem]['quantity'] * $carrito[$indiceItem]['unit_amount'];
        }

        self::guardarCarrito($carrito);
        return count($carrito);
    }

    // Elimina un ítem del carrito
    static public function eliminarItem($product_id) {
        $carrito = self::obtenerCarrito();
        $nuevoCarrito = array_filter($carrito, function($item) use ($product_id) {
            return $item['product_id'] != $product_id;
        });

        self::guardarCarrito(array_values($nuevoCarrito));
        return $nuevoCarrito;
    }

    // Incrementa la cantidad de un ítem específico en el carrito
    static public function aumentarCantidad($product_id) {
        return self::modificarCantidad($product_id, true);
    }

    // Decrementa la cantidad de un ítem específico en el carrito
    static public function disminuirCantidad($product_id) {
        return self::modificarCantidad($product_id, false);
    }

    // Modifica la cantidad de un ítem, incrementando o decrementando
    static private function modificarCantidad($product_id, $incrementar) {
        $carrito = self::obtenerCarrito();
        $indiceItem = self::buscarIndiceItem($carrito, $product_id);

        if (!is_null($indiceItem)) {
            $cantidadModificada = $incrementar ? 1 : -1;
            $carrito[$indiceItem]['quantity'] += $cantidadModificada;

            if ($carrito[$indiceItem]['quantity'] > 0) {
                $carrito[$indiceItem]['total_amount'] = $carrito[$indiceItem]['quantity'] * $carrito[$indiceItem]['unit_amount'];
            } else {
                unset($carrito[$indiceItem]);
            }

            self::guardarCarrito($carrito);
        }

        return $carrito;
    }

    // Actualiza los precios de los ítems del carrito basado en los precios más recientes
    static public function actualizarPrecios() {
        $carrito = self::obtenerCarrito();

        foreach ($carrito as &$item) {
            $producto = Product::find($item['product_id'], ['discount_price']);
            if ($producto) {
                $item['unit_amount'] = $producto->discount_price;
                $item['total_amount'] = $item['quantity'] * $item['unit_amount'];
            }
        }

        self::guardarCarrito($carrito);
        return $carrito;
    }

    // Calcula el total del carrito
    static public function calcularTotal($items) {
        return array_reduce($items, function($total, $item) {
            return $total + $item['total_amount'];
        }, 0);
    }

    // Vacía completamente el carrito
    static public function vaciarCarrito() {
        Cookie::queue(Cookie::forget('carrito'));
    }
}
