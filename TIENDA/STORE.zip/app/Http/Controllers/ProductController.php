<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function show($slug)
    {
        $product = Product::where('slug', $slug)->firstOrFail();

        switch ($product->product_type) {
            case 'digital':
                return redirect()->route('product.digital.show', ['slug' => $slug]);
            case 'physical':
                return redirect()->route('product.physical.show', ['slug' => $slug]);
            case 'ecard':
                return redirect()->route('product.ecard.show', ['slug' => $slug]);
            default:
                abort(404);
        }
    }
}
