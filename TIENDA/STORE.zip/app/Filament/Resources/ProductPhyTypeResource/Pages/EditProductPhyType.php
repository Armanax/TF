<?php

namespace App\Filament\Resources\ProductPhyTypeResource\Pages;

use App\Filament\Resources\ProductPhyTypeResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditProductPhyType extends EditRecord
{
    protected static string $resource = ProductPhyTypeResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
