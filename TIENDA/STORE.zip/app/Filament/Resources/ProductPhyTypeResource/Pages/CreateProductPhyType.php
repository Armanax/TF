<?php

namespace App\Filament\Resources\ProductPhyTypeResource\Pages;

use App\Filament\Resources\ProductPhyTypeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateProductPhyType extends CreateRecord
{
    protected static string $resource = ProductPhyTypeResource::class;
}
