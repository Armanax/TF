<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Filament\Resources\ProductResource\RelationManagers;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Group;
use Filament\Forms\Components\MarkdownEditor;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\ToggleButtons;
use Filament\Forms\Form;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Str;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-star';

    protected static ?string $recordTitleAttribute = 'name';

    protected static ?int $navigationSort = 3;

    public static function getLabel(): string
    {
        return 'producto';
    }

    public static function getPluralLabel(): string
    {
        return 'Productos';
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Group::make()->schema([
                    Section::make('Información del producto')->schema([
                        Section::make('Tipo de producto')->schema([
                            ToggleButtons::make('product_type')
                                ->label('Tipo de Producto')
                                ->options([
                                    'digital' => 'Digital',
                                    'physical' => 'Físico',
                                    'ecard' => 'E-card',
                                ])
                                ->required()
                                ->inline()
                                ->reactive()
                                ->afterStateUpdated(fn ($state, callable $set) => $set('gametype', 'base')),

                            ToggleButtons::make('gametype')
                                ->label('Tipo de edición')
                                ->options([
                                    'base' => 'Edición Base',
                                    'edition' => 'Edición Especial',
                                    'dlc' => 'DLC',
                                ])
                                ->default('base')
                                ->required()
                                ->inline()
                                ->reactive()
                                ->visible(fn (callable $get) => $get('product_type') === 'digital'),
                            
                            Select::make('parent_products_id')
                                ->label('Producto Principal')
                                ->searchable()
                                ->relationship('parentGame', 'name', function ($query) {
                                    return $query->where('product_type', 'digital');
                                })
                                ->visible(fn (callable $get) => in_array($get('gametype'), ['edition', 'dlc']))
                                ->required(fn (callable $get) => in_array($get('gametype'), ['edition', 'dlc'])),
                        ]),

                        TextInput::make('name')
                            ->label('Nombre')
                            ->required()
                            ->live(onBlur: true)
                            ->maxLength(255)
                            ->afterStateUpdated(function(string $operation, $state, Set $set){
                                if($operation !== 'create'){
                                    return;
                                }
                                $set('slug', Str::slug($state));
                            }),

                        TextInput::make('label')
                            ->label('Etiqueta')
                            ->required()
                            ->maxLength(255)
                            ->hintIcon('heroicon-o-exclamation-circle', tooltip: 'La etiqueta funciona para mostrar un nombre resumido en las tarjetas de producto'),

                        TextInput::make('slug')
                            ->label('Slug')
                            ->required()
                            ->maxLength(255)
                            ->disabled()
                            ->dehydrated()
                            ->unique(Product::class, 'slug', ignoreRecord: true),

                        DatePicker::make('release_date')
                            ->label('Fecha de Lanzamiento')
                            ->required()
                            ->displayFormat('Y-m-d')
                            ->format('Y-m-d')
                            ->columnSpanFull()
                            ->rules('required|date'),
                                        
                        MarkdownEditor::make('description')
                            ->label('Descripción')
                            ->required()
                            ->columnSpanFull(),

                        Section::make('Requisitos del sistema')->schema([
                            MarkdownEditor::make('minimum_requirements')
                                ->label('Requisitos mínimos del sistema')
                                ->columnSpanFull(),

                            MarkdownEditor::make('recommended_requirements')
                                ->label('Requisitos recomendados del sistema')
                                ->columnSpanFull()
                        ])
                        ->reactive()
                        ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Repeater::make('attributes')
                            ->label('Atributos del Producto')
                            ->relationship('attributes')
                            ->schema([
                                TextInput::make('attribute_key')
                                    ->label('Nombre del Atributo')
                                    ->required()
                                    ->columnSpan(1),
                                TextInput::make('attribute_value')
                                    ->label('Valor del Atributo')
                                    ->required()
                                    ->columnSpan(1),
                            ])
                            ->columns(2)
                            ->minItems(1)
                            ->createItemButtonLabel('Añadir Atributo')
                            ->columnSpanFull()
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'physical'),
                    ])->columns(2),

                    Section::make('Media')->schema([
                        
                        FileUpload::make('image_path')
                            ->label('Imagen de Portada')
                            ->hintIcon('heroicon-o-exclamation-circle', tooltip: 'Esta imagen será la imagen de portada de la tarjeta de producto')
                            ->required()
                            ->image() 
                            ->disk('public') 
                            ->directory('images') 
                            ->visibility('public') 
                            ->deletable(true) 
                            ->placeholder('Sube una imagen'),
                    
                        FileUpload::make('images')
                            ->label('Imágenes Adicionales')
                            ->hintIcon('heroicon-o-exclamation-circle', tooltip: 'Puedes subir múltiples imágenes del producto aquí')
                            ->helperText('Añade las imágenes adicionales del producto.')
                            ->multiple()
                            ->image()
                            ->disk('public')
                            ->directory('images')
                            ->visibility('public')
                            ->deletable(true)
                            ->placeholder('Sube imágenes'),
                    
                    ])
                ])->columnSpan(2),

                Group::make()->schema([
                    Section::make('Precio')->schema([
                        TextInput::make('price')
                            ->label('Precio')
                            ->numeric()
                            ->required()
                            ->prefix('COP')
                            ->reactive()
                            ->live(onBlur: true)
                            ->afterStateUpdated(function ($state, callable $set) {
                                $set('discount_price', $state);
                            }),

                        TextInput::make('discount_percentage')
                            ->label('Porcentaje de Descuento')
                            ->numeric()
                            ->suffix('%')
                            ->reactive()
                            ->live(onBlur: true)
                            ->afterStateUpdated(function ($state, callable $set, callable $get) {
                                $state = is_numeric($state) ? (float) $state : 0; 
                                $price = is_numeric($get('price')) ? (float) $get('price') : 0; 
                                $discountedPrice = $price - ($price * ($state / 100));
                                $set('discount_price', $discountedPrice);
                            }),

                        TextInput::make('discount_price')
                            ->label('Precio con Descuento')
                            ->numeric()
                            ->disabled()
                            ->dehydrated(true)
                            ->prefix('COP')
                            ->reactive(),
                    ]),

                    Section::make('Asociaciones')->schema([
                        Select::make('company_id')
                            ->label('Compañía')
                            ->searchable()
                            ->preload()
                            ->relationship('company', 'name'),

                        Select::make('genres')
                            ->label('Géneros')
                            ->relationship('genres', 'name')
                            ->multiple()
                            ->required()
                            ->searchable()
                            ->preload()
                            ->helperText('Selecciona múltiples géneros para este juego.')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Select::make('platform_id')
                            ->label('Plataforma')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('platform', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Select::make('publisher_id')
                            ->label('Editor')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('publisher', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Select::make('developer_id')
                            ->label('Desarrollador')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('developer', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Select::make('region_id')
                            ->label('Región')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('region', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'digital'),

                        Select::make('ecard_use_id')
                            ->label('Uso de Ecard')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('EcardUse', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'ecard'),

                        Select::make('product_phy_type_id')
                            ->label('Tipo de Producto Físico')
                            ->required()
                            ->searchable()
                            ->preload()
                            ->relationship('ProductPhyType', 'name')
                            ->reactive()
                            ->visible(fn (callable $get) => $get('product_type') === 'physical'),
                    ]),

                    Section::make('Estado')->schema([
                        Toggle::make('in_stock')
                            ->label('En Stock')
                            ->required()
                            ->default(true),
                        
                        Toggle::make('is_active')
                            ->label('Activo')
                            ->required()
                            ->default(true),
                        
                        Toggle::make('is_featured')
                            ->label('Destacado')
                            ->required(),
                        
                        Toggle::make('on_sale')
                            ->label('En Venta')
                            ->required()
                    ])
                ])->columnSpan(1)
            ])->columns(3);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('product_type')
                    ->label('Tipo de Producto')
                    ->formatStateUsing(function ($state) {
                        return match ($state) {
                            'digital' => 'Digital',
                            'physical' => 'Físico',
                            'ecard' => 'Ecard',
                            default => $state,
                        };
                    }),
                
                TextColumn::make('name')
                    ->label('Nombre')
                    ->searchable(),
                
                TextColumn::make('price')
                    ->label('Precio')
                    ->money('COP')
                    ->formatStateUsing(function ($state, $record) {
                        $originalPrice = $record->price;
                        $discountPercentage = number_format($record->discount_percentage, 0);
                        $discountedPrice = $record->discount_price;
                        if ($discountPercentage > 0) {
                            return "<s style='font-size: smaller;'>\${$originalPrice}</s> <span style='font-size: smaller;'>{$discountPercentage}%</span> <span style='font-size: larger; font-weight: bold;'>\${$discountedPrice}</span>";
                        }
                        return "\${$originalPrice}";
                    })
                    ->html()
                    ->sortable(),
                
                IconColumn::make('is_featured')
                    ->label('Destacado')
                    ->boolean(),

                IconColumn::make('on_sale')
                    ->label('En Venta')
                    ->boolean(),

                IconColumn::make('in_stock')
                    ->label('En Stock')
                    ->boolean(),

                IconColumn::make('is_active')
                    ->label('Activo')
                    ->boolean(),
                    
                TextColumn::make('created_at')
                    ->label('Fecha de Creación')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                
                TextColumn::make('updated_at')
                    ->label('Fecha de Actualización')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('product_type')
                    ->label('Tipo de Producto')
                    ->options([
                        'digital' => 'Digital',
                        'physical' => 'Físico',
                        'ecard' => 'Ecard',
                    ]),
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make()->label('Ver'),
                    EditAction::make()->label('Editar'),
                    DeleteAction::make()->label('Eliminar'),
                ])
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make()->label('Eliminar Seleccionados'),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name'];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
