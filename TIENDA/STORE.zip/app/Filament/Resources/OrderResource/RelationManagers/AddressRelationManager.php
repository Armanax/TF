<?php

namespace App\Filament\Resources\OrderResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class AddressRelationManager extends RelationManager
{
    protected static string $relationship = 'address';
    protected static ?string $title = 'Direcciones';

    public function form(Form $form): Form {
        return $form
            ->schema([

                TextInput::make('first_name')
                    ->label('Nombre')
                    ->required()
                    ->maxLength(255),

                TextInput::make('last_name')
                    ->label('Apellido')
                    ->required()
                    ->maxLength(255),

                TextInput::make('phone')
                    ->label('Teléfono')
                    ->required()
                    ->tel()
                    ->maxLength(20),

                TextInput::make('city')
                    ->label('Ciudad')
                    ->required()
                    ->maxLength(255),

                TextInput::make('state')
                    ->label('Estado/Provincia')
                    ->required()
                    ->maxLength(255),

                TextInput::make('zip_code')
                    ->label('Código Postal')
                    ->required()
                    ->numeric()
                    ->maxLength(10),

                Textarea::make('street_address')
                    ->label('Dirección')
                    ->required()
                    ->columnSpanFull(),

            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('street_address')
            ->columns([
                TextColumn::make('fullname')
                    ->label('Nombre Completo'),

                TextColumn::make('phone')
                    ->label('Teléfono'),

                TextColumn::make('city')
                    ->label('Ciudad'),

                TextColumn::make('state')
                    ->label('Estado/Provincia'),

                TextColumn::make('zip_code')
                    ->label('Código Postal'),

                TextColumn::make('street_address')
                    ->label('Dirección'),

            ])
            ->filters([
                //
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->label('Crear direcciones'),
                
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make(),
                    EditAction::make(),
                    DeleteAction::make(),

                ])
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}
