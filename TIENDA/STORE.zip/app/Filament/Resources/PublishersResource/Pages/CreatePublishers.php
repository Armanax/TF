<?php

namespace App\Filament\Resources\PublishersResource\Pages;

use App\Filament\Resources\PublishersResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePublishers extends CreateRecord
{
    protected static string $resource = PublishersResource::class;
}
