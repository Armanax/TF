<?php

namespace App\Filament\Resources\HomePageSliderResource\Pages;

use App\Filament\Resources\HomePageSliderResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditHomePageSlider extends EditRecord
{
    protected static string $resource = HomePageSliderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
