<?php

namespace App\Filament\Resources\HomePageSliderResource\Pages;

use App\Filament\Resources\HomePageSliderResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListHomePageSliders extends ListRecords
{
    protected static string $resource = HomePageSliderResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
