<?php

namespace App\Filament\Resources\PlatformsResource\Pages;

use App\Filament\Resources\PlatformsResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditPlatforms extends EditRecord
{
    protected static string $resource = PlatformsResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
