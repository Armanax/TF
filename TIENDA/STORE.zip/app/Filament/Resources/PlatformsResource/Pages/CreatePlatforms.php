<?php

namespace App\Filament\Resources\PlatformsResource\Pages;

use App\Filament\Resources\PlatformsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePlatforms extends CreateRecord
{
    protected static string $resource = PlatformsResource::class;
}
