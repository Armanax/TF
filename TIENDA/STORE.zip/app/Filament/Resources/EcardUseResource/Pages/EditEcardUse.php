<?php

namespace App\Filament\Resources\EcardUseResource\Pages;

use App\Filament\Resources\EcardUseResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditEcardUse extends EditRecord
{
    protected static string $resource = EcardUseResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
