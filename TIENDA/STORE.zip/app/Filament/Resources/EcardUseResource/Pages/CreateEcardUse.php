<?php

namespace App\Filament\Resources\EcardUseResource\Pages;

use App\Filament\Resources\EcardUseResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateEcardUse extends CreateRecord
{
    protected static string $resource = EcardUseResource::class;
}
