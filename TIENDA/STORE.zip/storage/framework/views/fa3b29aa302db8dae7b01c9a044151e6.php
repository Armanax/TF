<div
    <?php echo e($attributes->class(['fi-fo-field-wrp-helper-text text-sm text-gray-500'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\vendor\filament\forms\src\/../resources/views/components/field-wrapper/helper-text.blade.php ENDPATH**/ ?>