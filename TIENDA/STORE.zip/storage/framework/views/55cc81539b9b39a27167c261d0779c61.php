<div class="homepage_all">
    <div class="homepage_carrusel">
        <!-- Slider -->
            <div data-hs-carousel='{
                    "loadingClasses": "opacity-0",
                    "isAutoPlay": true
                }' class="relative h-full">
                <div class="hs-carousel relative overflow-hidden w-full h-full" wire:ignore>
                    <div class="hs-carousel-body absolute top-0 bottom-0 start-0 flex flex-nowrap transition-transform duration-700">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="hs-carousel-slide flex justify-center h-full">
                                <div class="homepage_cardFeatured">
                                    <div class="homepage_cardFeatured_image">
                                        <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="imagen">
                                    </div>
                                    <div class="homepage_cardFeatured_card">
                                        <div class="homepage_cardFeatured_cardname">
                                            <h1><?php echo e($product->label); ?></h1>
                                        </div>
                                        <div class="homepage_cardFeatured_allinfo">
                                            <div class="homepage_cardFeatured_expoinfo">
                                                <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                                                    <p><?php echo e($product->platform->name); ?></p>
                                                    <p><?php echo e($product->region->name); ?></p>
                                                <?php elseif($product->product_type == 'physical'): ?>
                                                    <p><?php echo e($product->product_phy_type->name); ?></p>
                                                <?php elseif($product->product_type == 'ecard'): ?>
                                                    <p><?php echo e($product->ecardUse->name); ?></p>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                            <div class="homepage_cardFeatured_expoprices">
                                                <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                                                <p style="font-weight: 700;">$<?php echo e(floor($product->discount_price)); ?></p>
                                                <?php else: ?>
                                                    <p style="text-decoration: line-through;">$<?php echo e(floor($product->price)); ?></p>
                                                    <p style="color: red;"><?php echo e(floor($product->discount_percentage)); ?>%</p>
                                                    <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                            <div class="homepage_cardFeatured_buttons">
                                                <button class="homepage_cardFeatured_buttons-buy" wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'>
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                                        <path d="m15 11-1 9" />
                                                        <path d="m19 11-4-7" />
                                                        <path d="M2 11h20" />
                                                        <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                                                        <path d="M4.5 15.5h15" />
                                                        <path d="m5 11 4-7" />
                                                        <path d="m9 11 1 9" />
                                                    </svg>
                                                    <p>Comprar</p>
                                                </button>
                                                <button class="homepage_cardFeatured_buttons-wish" wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#000' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                                                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                                                    </svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->                             
                    </div>
                </div>

                <button type="button" class="hs-carousel-prev hs-carousel:disabled:opacity-50 disabled:pointer-events-none absolute inset-y-0 left-0 inline-flex justify-center items-center w-[46px] h-[46px] text-gray-800 hover:bg-gray-800/10 rounded-full dark:text-white dark:hover:bg-white/10 m-auto">
                    <span class="text-2xl" aria-hidden="true">
                        <svg class="flex-shrink-0 size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m15 18-6-6 6-6"></path>
                        </svg>
                    </span>
                    <span class="sr-only">Previous</span>
                </button>
                
                
                <button type="button" class="hs-carousel-next hs-carousel:disabled:opacity-50 disabled:pointer-events-none absolute inset-y-0 right-0 inline-flex justify-center items-center w-[46px] h-[46px] text-gray-800 hover:bg-gray-800/10 rounded-full dark:text-white dark:hover:bg-white/10 m-auto">
                    <span class="sr-only">Next</span>
                    <span class="text-2xl" aria-hidden="true">
                        <svg class="flex-shrink-0 size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m9 18 6-6-6-6"></path>
                        </svg>
                    </span>
                </button>

            </div>
        <!-- End Slider -->
    </div>
    <div class="homepage_expositor">
        <div class="homepage_deals">
            <h1>Ultimas Ofertas</h1>
            <div class="homepage_dealsExpositor flex flex-wrap">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
                    <a href="<?php echo e(route('product.show', ['slug' => $product->slug])); ?>" class="homepage_linkCard flex flex-col w-full h-[90%]">
                        <div class="homepage_imgCardDigital flex w-full h-[55%]">
                            <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="img" class="w-full h-full">
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->region->name); ?></p>-<p class="mx-[5%]"><?php echo e($product->platform->name); ?></p>
                        </span>
                        <?php else: ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->label); ?></p>
                        </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="homepage_PricesDigital flex w-full h-[35%]">
                            <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                                <div class="homepage_allprices flex justify-center items-center w-full h-full">
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php else: ?>
                                <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                                    <?php echo e(floor($product->discount_percentage)); ?>%
                                </span>
                                <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                                    <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                        <p>$<?php echo e(floor($product->price)); ?></p>
                                    </span>
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>         
                    </a>
                    <div class="homepage_buttons flex justify-between w-full h-[10%]">
                        <button wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                <path d="m15 11-1 9" />
                                <path d="m19 11-4-7" />
                                <path d="M2 11h20" />
                                <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                                <path d="M4.5 15.5h15" />
                                <path d="m5 11 4-7" />
                                <path d="m9 11 1 9" />
                            </svg>
                            <p>Comprar</p>
                        </button>
                        <button wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#fff' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div> 

        <div class="homepage_deals">
            <h1>Ultimos Juegos Digitales</h1>
            <div class="homepage_dealsExpositor flex flex-wrap">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $digitalProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
                    <a href="<?php echo e(route('product.show', ['slug' => $product->slug])); ?>" class="homepage_linkCard flex flex-col w-full h-[90%]">
                        <div class="homepage_imgCardDigital flex w-full h-[55%]">
                            <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="img" class="w-full h-full">
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->region->name); ?></p>-<p class="mx-[5%]"><?php echo e($product->platform->name); ?></p>
                        </span>
                        <?php else: ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->label); ?></p>
                        </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="homepage_PricesDigital flex w-full h-[35%]">
                            <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                                <div class="homepage_allprices flex justify-center items-center w-full h-full">
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php else: ?>
                                <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                                    <?php echo e(floor($product->discount_percentage)); ?>%
                                </span>
                                <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                                    <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                        <p>$<?php echo e(floor($product->price)); ?></p>
                                    </span>
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>         
                    </a>
                    <div class="homepage_buttons flex justify-between w-full h-[10%]">
                        <button wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                <path d="m15 11-1 9" />
                                <path d="m19 11-4-7" />
                                <path d="M2 11h20" />
                                <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                                <path d="M4.5 15.5h15" />
                                <path d="m5 11 4-7" />
                                <path d="m9 11 1 9" />
                            </svg>
                            <p>Comprar</p>
                        </button>
                        <button wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#fff' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="homepage_deals">
            <h1>Ultimos Productos Fisicos</h1>
            <div class="homepage_dealsExpositor flex flex-wrap">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $PhysicalProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
                    <a href="<?php echo e(route('product.show', ['slug' => $product->slug])); ?>" class="homepage_linkCard flex flex-col w-full h-[90%]">
                        <div class="homepage_imgCardDigital flex w-full h-[55%]">
                            <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="img" class="w-full h-full">
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->region->name); ?></p>-<p class="mx-[5%]"><?php echo e($product->platform->name); ?></p>
                        </span>
                        <?php else: ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->label); ?></p>
                        </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="homepage_PricesDigital flex w-full h-[35%]">
                            <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                                <div class="homepage_allprices flex justify-center items-center w-full h-full">
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php else: ?>
                                <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                                    <?php echo e(floor($product->discount_percentage)); ?>%
                                </span>
                                <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                                    <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                        <p>$<?php echo e(floor($product->price)); ?></p>
                                    </span>
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>         
                    </a>
                    <div class="homepage_buttons flex justify-between w-full h-[10%]">
                        <button wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                <path d="m15 11-1 9" />
                                <path d="m19 11-4-7" />
                                <path d="M2 11h20" />
                                <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                                <path d="M4.5 15.5h15" />
                                <path d="m5 11 4-7" />
                                <path d="m9 11 1 9" />
                            </svg>
                            <p>Comprar</p>
                        </button>
                        <button wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#fff' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="homepage_deals">
            <h1>Ultimas Tarjetas de Regalo</h1>
            <div class="homepage_dealsExpositor flex flex-wrap">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $EcardProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
                    <a href="<?php echo e(route('product.show', ['slug' => $product->slug])); ?>" class="homepage_linkCard flex flex-col w-full h-[90%]">
                        <div class="homepage_imgCardDigital flex w-full h-[55%]">
                            <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="img" class="w-full h-full">
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->region->name); ?></p>-<p class="mx-[5%]"><?php echo e($product->platform->name); ?></p>
                        </span>
                        <?php else: ?>
                        <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                            <p class="mx-[5%]"><?php echo e($product->label); ?></p>
                        </span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="homepage_PricesDigital flex w-full h-[35%]">
                            <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                                <div class="homepage_allprices flex justify-center items-center w-full h-full">
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php else: ?>
                                <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                                    <?php echo e(floor($product->discount_percentage)); ?>%
                                </span>
                                <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                                    <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                        <p>$<?php echo e(floor($product->price)); ?></p>
                                    </span>
                                    <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                        <p>$<?php echo e(floor($product->discount_price)); ?></p>
                                    </span>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>         
                    </a>
                    <div class="homepage_buttons flex justify-between w-full h-[10%]">
                        <button wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                <path d="m15 11-1 9" />
                                <path d="m19 11-4-7" />
                                <path d="M2 11h20" />
                                <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                                <path d="M4.5 15.5h15" />
                                <path d="m5 11 4-7" />
                                <path d="m9 11 1 9" />
                            </svg>
                            <p>Comprar</p>
                        </button>
                        <button wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#fff' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                            </svg>
                        </button>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        
        
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/home-page.blade.php ENDPATH**/ ?>