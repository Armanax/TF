<div class="checkout_all">
    <h1 class="checkout_title">Pagar</h1>
    <form wire:submit.prevent='placeOrder'>
      <div class="checkout_container">
        <div class="checkout_left">
          <!-- Card -->
          <div class="checkout_card">
            <!-- Dirección de Envío -->
            <div class="checkout_section">
              <h2 class="checkout_section_title">Dirección de Envío</h2>
              <div class="checkout_input_group">
                <div>
                  <label for="first_name" class="checkout_label">Nombre</label>
                  <input wire:model='first_name' class="checkout_input <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="first_name" type="text">
                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="checkout_error_message"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div>
                  <label for="last_name" class="checkout_label">Apellido</label>
                  <input wire:model='last_name' class="checkout_input <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="last_name" type="text">
                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="checkout_error_message"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
              </div>
              <div class="checkout_input_group">
                <label for="phone" class="checkout_label">Teléfono</label>
                <input wire:model='phone' class="checkout_input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" type="text">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="checkout_error_message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="checkout_input_group">
                <label for="address" class="checkout_label">Dirección</label>
                <input wire:model='street_address' class="checkout_input <?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" type="text">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['street_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="checkout_error_message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="checkout_input_group">
                <label for="city" class="checkout_label">Ciudad</label>
                <input wire:model='city' class="checkout_input <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="city" type="text">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="checkout_error_message"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="checkout_input_group">
                <div>
                  <label for="state" class="checkout_label">Departamento</label>
                  <input wire:model='state' class="checkout_input <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="state" type="text">
                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="checkout_error_message"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div>
                  <label for="zip" class="checkout_label">Código Postal</label>
                  <input wire:model='zip_code' class="checkout_input <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> checkout_input_error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="zip" type="text">
                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="checkout_error_message"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
              </div>
            </div>
            <div class="checkout_payment_section">
              <div class="checkout_section_title">Seleccione el Método de Pago</div>
              <ul class="checkout_payment_methods">
                <li>
                  <input wire:model='payment_method' class="checkout_payment_radio" id="stripe" type="radio" value="stripe">
                  <label class="checkout_payment_label" for="stripe">
                    <div class="checkout_payment_name">Stripe</div>
                    <svg class="checkout_payment_icon" aria-hidden="true" viewbox="0 0 14 10">
                      <path d="M1 5h12m0 0L9 1m4 4L9 9" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                    </svg>
                  </label>
                </li>
              </ul>
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="checkout_error_message"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
          </div>
        </div>
        <div class="checkout_right">
          <div class="checkout_card">
            <div class="checkout_section_title">Resumen del Pedido</div>
            <div class="checkout_summary_item">
              <span>Subtotal</span>
              <span><?php echo e(Number::currency($grand_total, 'COP')); ?></span>
            </div>
            <div class="checkout_summary_item">
              <span>Costo de Envío</span>
              <span><?php echo e(Number::currency(0, 'COP')); ?></span>
            </div>
            <hr class="checkout_divider">
            <div class="checkout_summary_item">
              <span>Total</span>
              <span><?php echo e(Number::currency($grand_total, 'COP')); ?></span>
            </div>
          </div>
          <button class="checkout_button">
            <span wire:loading.remove>Realizar Pedido</span>
            <span wire:loading>Procesando...</span>
          </button>
          <div class="checkout_card">
            <div class="checkout_section_title">Resumen del Carrito</div>
            <ul class="checkout_cart_list">
              <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="checkout_cart_item" wire:key='<?php echo e($ci['product_id']); ?>'>
                  <div class="checkout_cart_item_info">
                    <img alt="<?php echo e($ci['name']); ?>" class="checkout_cart_item_image" src="<?php echo e($ci['image']); ?>">
                    <div>
                      <p class="checkout_cart_item_name"><?php echo e($ci['name']); ?></p>
                      <p class="checkout_cart_item_quantity">Cantidad: <?php echo e($ci['quantity']); ?></p>
                    </div>
                    <div class="checkout_cart_item_price">
                      <?php echo e(Number::currency($ci['total_amount'], 'COP')); ?>

                    </div>
                  </div>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
          </div>
        </div>
      </div>
    </form>
  </div>
  <?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/checkout-page.blade.php ENDPATH**/ ?>