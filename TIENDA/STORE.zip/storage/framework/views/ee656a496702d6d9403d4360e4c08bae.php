<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>