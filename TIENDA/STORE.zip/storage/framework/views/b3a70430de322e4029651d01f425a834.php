
<div class="register_all">
  <div class="register_container">
    <h1 class="register_title">Registrarse</h1>
    <p class="register_text">
      ¿Ya tienes una cuenta?
      <a href="/login" class="register_link">Inicia sesión aquí</a>
    </p>
    
    <hr class="register_hr">

    <form class="register_form" wire:submit.prevent='save'>
      <div class="register_input-group">
        <label for="name" class="register_label">Nombre</label>
        <div>
          <input type="text" id="name" class="register_input" wire:model="name" aria-describedby="name-error">
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-xs text-red-600 mt-2" id="name-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <div class="register_input-group">
        <label for="email" class="register_label">Correo Electrónico</label>
        <div>
          <input type="email" id="email" class="register_input" wire:model="email" aria-describedby="email-error">
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-xs text-red-600 mt-2" id="email-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <div class="register_input-group">
        <label for="password" class="register_label">Contraseña</label>
        <div>
          <input type="password" id="password" class="register_input" wire:model="password" aria-describedby="password-error">
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-xs text-red-600 mt-2" id="password-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <button type="submit" class="register_button">Registrarse</button>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/auth/register-page.blade.php ENDPATH**/ ?>