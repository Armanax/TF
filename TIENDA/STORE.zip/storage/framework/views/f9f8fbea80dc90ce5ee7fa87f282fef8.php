<div class="forg_all">
  <div class="forg_container">
      <h1 class="forg_title">¿Olvidaste tu contraseña?</h1>
      <p class="forg_text">¿Recuerdas tu contraseña? <a href="/login" class="forg_link">Inicia sesión aquí</a></p>
      
      <form class="forg_form" wire:submit.prevent='save'>
          <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
              <div class="mt-2 bg-green-500 text-sm text-white rounded-lg p-4 mb-4" role="alert">
                <?php echo e(session('success')); ?>

              </div>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

          <div class="forg_input-group">
              <label for="email" class="forg_label">Correo electrónico</label>
              <input type="email" id="email" class="forg_input" wire:model="email" aria-describedby="email-error">
              
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="forg_error-icon absolute inset-y-0 right-0 flex items-center pr-3">
                  <svg class="h-5 w-5 text-red-500" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/>
                  </svg>
              </div>
              <p class="text-xs text-red-600 mt-2" id="email-error"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>
          <button type="submit" class="forg_button">Restablecer contraseña</button>
      </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/auth/forgot-password.blade.php ENDPATH**/ ?>