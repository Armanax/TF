<div class="advance_all">
    <div class="advance_searchtools">
        <div class="advance_Optionbar1">
            <select wire:model="platform" id="platform" class="advance_mulipleSelect">
                <option value="">Plataforma</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($platform->id); ?>"><?php echo e($platform->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <div class="advance_allcategoriesbutton" x-data="{ open: false }" @click.away="open = false">
                <button @click="open = !open" class="advance_dropbtn">
                    Géneros (<?php echo e(count($selectedGenres)); ?>)
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-chevron-down"><path d="m6 9 6 6 6-6"/></svg>
                </button>
                <div x-show="open" class="advance_dropdown-content">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div wire:loading.remove wire:click="toggleGenre(<?php echo e($genre->id); ?>)"
                             class="advance_dropdown-item <?php echo e(in_array($genre->id, $selectedGenres) ? 'selected' : ''); ?>">
                            <?php echo e($genre->name); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <span class="advance_loadercategories" wire:loading wire:target="search,toggleGenre">
                        <svg class="loading-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    </span>                    
                    <button wire:click="clearSelectedGenres" class="advance_clear-button">
                        <span wire:loading.remove wire:target="clearSelectedGenres" class="advance_loadclear">Borrar todos</span>
                        <span wire:loading wire:target="clearSelectedGenres" class="advance_loadclear">
                            <p>Borrando...</p>
                        </span>
                    </button>
                </div>
            </div>
            
            <select wire:model="region" id="regions" class="advance_mulipleSelect">
                <option value="">Región</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select wire:model="company" id="companies" class="advance_mulipleSelect">
                <option value="">Compañias</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select wire:model="ecarduse" id="ecardUse" class="advance_mulipleSelect">
                <option value="">Uso de Ecard</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ecardUses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecardUse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ecardUse->id); ?>"><?php echo e($ecardUse->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select wire:model="sortBy" id="sortBy" class="advance_mulipleSelect">
                <option value="">Organizado por</option>
                <option value="Precio: Menor a Mayor">Precio: Menor a Mayor</option>
                <option value="Precio: Mayor a Menor">Precio: Mayor a Menor</option>
                <option value="Salida: Reciente">Salida: Reciente</option>
                <option value="Salida: Antigua">Salida: Antigua</option>
            </select>
        </div>
        <div class="advance_Optionbar2">
            <span class="">Precio entre: 
                <input type="number" wire:model="minPrice" class="advance_numberImput" placeholder="Min">
                y 
                <input type="number" wire:model="maxPrice" class="advance_numberImput" placeholder="Max">
            </span>
            <label class="">
                <input type="checkbox" wire:model="inStock" class="advance_checkBox">
                <span class="ml-2">Está en stock</span>
            </label>
            <select wire:model="typeOfProduct" id="typeOfProduct" class="advance_mulipleSelect2">
                <option value="">Productos</option> <!-- Opción para mostrar todos -->
                <option value="digital">Productos Digitales</option>
                <option value="physical">Productos Físicos</option>
                <option value="ecard">Tarjetas de Regalo</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $productPhyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productPhyType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($productPhyType->id); ?>"><?php echo e($productPhyType->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>  
        </div>
        <div class="advance_Optionbar3">
            <button wire:click="search" class="advance_searchbutton">Filtrar</button>       
        </div>
    </div>
    <div class="homepage_dealsExpositor flex flex-wrap">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
            <a href="<?php echo e(route('product.show', ['slug' => $product->slug])); ?>" class="homepage_linkCard flex flex-col w-full h-[90%]">
                <div class="homepage_imgCardDigital flex w-full h-[55%]">
                    <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="img" class="w-full h-full">
                </div>
                <!--[if BLOCK]><![endif]--><?php if($product->product_type == 'digital'): ?>
                <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                    <p class="mx-[5%]"><?php echo e($product->region->name); ?></p>-<p class="mx-[5%]"><?php echo e($product->platform->name); ?></p>
                </span>
                <?php else: ?>
                <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                    <p class="mx-[5%]"><?php echo e($product->label); ?></p>
                </span>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="homepage_PricesDigital flex w-full h-[35%]">
                    <!--[if BLOCK]><![endif]--><?php if($product->discount_percentage < 1): ?>
                        <div class="homepage_allprices flex justify-center items-center w-full h-full">
                            <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                <p>$<?php echo e(floor($product->discount_price)); ?></p>
                            </span>
                        </div>
                    <?php else: ?>
                        <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                            <?php echo e(floor($product->discount_percentage)); ?>%
                        </span>
                        <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                            <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                <p>$<?php echo e(floor($product->price)); ?></p>
                            </span>
                            <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                <p>$<?php echo e(floor($product->discount_price)); ?></p>
                            </span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>         
            </a>
            <div class="homepage_buttons flex justify-between w-full h-[10%]">
                <button wire:click.prevent='addToCart(<?php echo e($product->id); ?>)'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                    <span class="h-full w-full flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                            <path d="m15 11-1 9" />
                            <path d="m19 11-4-7" />
                            <path d="M2 11h20" />
                            <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4" />
                            <path d="M4.5 15.5h15" />
                            <path d="m5 11 4-7" />
                            <path d="m9 11 1 9" />
                        </svg>
                        <p>Comprar</p>
                    </span>
                </button>
                <button wire:click.prevent="toggleWishlist(<?php echo e($product->id); ?>)" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="<?php echo e($this->isProductInWishlist($product->id) ? '#fff' : 'none'); ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                </button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <div class="pagination mt-4">
        <?php echo e($products->links()); ?>

    </div>
</div>


<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/advanced-search.blade.php ENDPATH**/ ?>