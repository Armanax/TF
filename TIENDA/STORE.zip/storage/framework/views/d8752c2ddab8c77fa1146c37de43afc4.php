<div class="login_all">
  <div class="login_container">
    <h1 class="login_title">Iniciar sesión</h1>
    <p class="login_text">
      ¿No tienes una cuenta aún?
      <a href="/register" class="login_link">Regístrate aquí</a>
    </p>
    
    <hr class="login_hr">

    <form class="login_form" wire:submit.prevent='save'>
      <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
        <div class="login_alert" role="alert">
          <?php echo e(session('error')); ?>

        </div>
      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

      <div class="login_input-group">
        <label for="email" class="login_label">Correo electrónico</label>
        <input type="email" id="email" class="login_input" wire:model="email" aria-describedby="email-error">         
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-xs text-red-600 mt-2" id="email-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <div class="login_input-group">
        <label for="password" class="login_label">Contraseña</label>
        <div class="login_forgot-container">
          <input type="password" id="password" class="login_input" wire:model="password" aria-describedby="password-error">
          <a href="/forgot" class="login_forgot-link">¿Olvidaste tu contraseña?</a>
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-xs text-red-600 mt-2" id="password-error"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <button type="submit" class="login_button">Iniciar sesión</button>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/auth/login-page.blade.php ENDPATH**/ ?>