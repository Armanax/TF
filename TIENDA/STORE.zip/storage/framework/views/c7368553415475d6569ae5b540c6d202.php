<div class="cancel_all">
    <section class="cancel_section">
      <div class="cancel_container">
        <div>
          <h1 class="cancel_title">
            ¡Pago Fallido! ¡Pedido Cancelado!
          </h1>
        </div>
      </div>
    </section>
</div>
  <?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/cancel-page.blade.php ENDPATH**/ ?>