<div class="success_all">
    <h1 class="success_title">Gracias. Su pedido ha sido recibido.</h1>
    <div class="success_container">
        <div class="success_left">
            <div class="success_card">
                <div class="success_section">
                    <h2 class="success_section_title">Dirección de Envío</h2>
                    <div class="success_input_group">
                        <div class="success_input_half">
                            <label for="first_name" class="success_label">Nombre</label>
                            <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->first_name); ?>" disabled>
                        </div>
                        <div class="success_input_half">
                            <label for="last_name" class="success_label">Apellido</label>
                            <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->last_name); ?>" disabled>
                        </div>
                    </div>
                    <div class="success_input_group">
                        <label for="phone" class="success_label">Teléfono</label>
                        <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->phone); ?>" disabled>
                    </div>
                    <div class="success_input_group">
                        <label for="address" class="success_label">Dirección</label>
                        <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->street_address); ?>" disabled>
                    </div>
                    <div class="success_input_group">
                        <label for="city" class="success_label">Ciudad</label>
                        <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->city); ?>" disabled>
                    </div>
                    <div class="success_input_group">
                        <div class="success_input_half">
                            <label for="state" class="success_label">Departamento</label>
                            <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->state); ?>" disabled>
                        </div>
                        <div class="success_input_half">
                            <label for="zip" class="success_label">Código Postal</label>
                            <input id="last_name" type="text" class="success_input" value="<?php echo e($order->address->zip_code); ?>" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="success_right">
            <div class="success_card">
                <h2 class="success_section_title">Resumen del Pedido</h2>
                <div class="success_summary_item">
                    <span>Número de Orden</span>
                    <span><?php echo e($order->id); ?></span>
                </div>
                <div class="success_summary_item">
                    <span>Fecha</span>
                    <span><?php echo e($order->created_at->format('d-m-Y')); ?></span>
                </div>
                <div class="success_summary_item">
                    <span>Total</span>
                    <span><?php echo e(Number::currency($order->grand_total, 'COP')); ?></span>
                </div>
                <div class="success_summary_item">
                    <span>Método de Pago</span>
                    <span><?php echo e($order->payment_method == 'stripe' ? 'Tarjeta de Credito' : ''); ?></span>
                </div>
            </div>
        </div>
    </div>
    <div class="success_card">
        <h2 class="success_section_title">Detalles del Pedido</h2>
        <div class="success_summary_item">
            <span>Subtotal</span>
            <span><?php echo e(Number::currency($order->grand_total, 'COP')); ?></span>
        </div>
        <div class="success_summary_item">
            <span>Descuento</span>
            <span><?php echo e(Number::currency(0, 'COP')); ?></span>
        </div>
        <div class="success_summary_item">
            <span>Envío</span>
            <span><?php echo e(Number::currency(0, 'COP')); ?></span>
        </div>
        <div class="success_summary_item">
            <span>Total</span>
            <span><?php echo e(Number::currency($order->grand_total, 'COP')); ?></span>
        </div>
    </div>
    <div class="success_shipping">
        <h2 class="success_section_title">Envío</h2>
        <div class="success_shipping_details">
            <div class="success_shipping_icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="full" height="full" fill="currentColor" class="text-white" viewBox="0 0 16 16">
                    <path d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5v-7zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456zM12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12v4zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"></path>
                </svg>
            </div>
            <div class="success_shipping_info">
                <p>Entrega en 24 Horas</p>
                <p><?php echo e(Number::currency(0, 'COP')); ?></p>
            </div>
        </div>
    </div>
    <div class="success_buttons">
        <a href="/search" class="success_button success_button_outline">Volver a comprar</a>
        <a href="/my-orders" class="success_button">Ver mis pedidos</a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/success-page.blade.php ENDPATH**/ ?>