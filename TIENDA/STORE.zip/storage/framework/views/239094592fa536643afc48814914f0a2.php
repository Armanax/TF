<div class="reset_all">
  <div class="reset_container">
    <h1 class="reset_title">Restablecer contraseña</h1>

    <form class="reset_form" wire:submit.prevent='save'>
      <div class="reset_input-group">
        <label for="password" class="reset_label">Contraseña</label>
        <input type="password" id="password" class="reset_input" wire:model="password">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <div class="reset_input-group">
        <label for="password_confirmation" class="reset_label">Confirmar Contraseña</label>
        <input type="password" id="password_confirmation" class="reset_input" wire:model="password_confirmation">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="text-xs text-red-600 mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
      </div>

      <button type="submit" class="reset_button">Guardar contraseña</button>
    </form>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/auth/reset-password.blade.php ENDPATH**/ ?>