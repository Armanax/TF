<div class="profile_edit_all">
    <div class="profile_edit_container">
      <h1 class="profile_edit_title">Editar Perfil</h1>
      
      
      <hr class="profile_edit_hr">
  
      <form class="profile_edit_form" wire:submit.prevent='updateProfile'>
        <!--[if BLOCK]><![endif]--><?php if(session('success')): ?>
          <div class="profile_edit_alert" role="alert">
            <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
          <div class="profile_edit_alert" role="alert">
            <?php echo e(session('error')); ?>

          </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
  
        <div class="profile_edit_input-group">
          <label for="name" class="profile_edit_label">Nombre</label>
          <input type="text" id="name" class="profile_edit_input" wire:model="name" aria-describedby="name-error">
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-red-600 mt-2" id="name-error"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
  
        <div class="profile_edit_input-group">
          <label for="email" class="profile_edit_label">Correo electrónico</label>
          <input type="email" id="email" class="profile_edit_input" wire:model="email" aria-describedby="email-error">         
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-red-600 mt-2" id="email-error"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
  
        <div class="profile_edit_input-group">
          <label for="password" class="profile_edit_label">Nueva Contraseña</label>
          <input type="password" id="password" class="profile_edit_input" wire:model="password" aria-describedby="password-error">
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-red-600 mt-2" id="password-error"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
  
        <div class="profile_edit_input-group">
          <label for="password_confirmation" class="profile_edit_label">Confirmar Contraseña</label>
          <input type="password" id="password_confirmation" class="profile_edit_input" wire:model="password_confirmation" aria-describedby="password_confirmation-error">
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-xs text-red-600 mt-2" id="password_confirmation-error"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
  
        <button type="submit" class="profile_edit_button">Guardar Cambios</button>
      </form>
    </div>
  </div>
  
 
  <?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/user-page.blade.php ENDPATH**/ ?>