<div class="detail_all">
    <h1 class="detail_pageTitle">Detalles de Orden</h1>
    <div class="detail_allcards">
        <?php
            $estado = '';
            $estado_pago = '';

            if ($order->status == 'pending') {
                $estado = '<span class="myorder_status-pending bg-blue-500 text-white py-1 px-3 rounded inline-block">Nuevo</span>';
            }
            if ($order->status == 'processing') {
                $estado = '<span class="myorder_status-pending bg-yellow-500 text-white py-1 px-3 rounded inline-block">Procesando</span>';
            }
            if ($order->status == 'completed') {
                $estado = '<span class="myorder_status-pending bg-green-500 text-white py-1 px-3 rounded inline-block">Enviado</span>';
            }
            if ($order->status == 'declined') {
                $estado = '<span class="myorder_status-pending bg-green-700 text-white py-1 px-3 rounded inline-block">Rechazado</span>';
            }
            if ($order->status == 'canceled') {
                $estado = '<span class="myorder_status-pending bg-red-700 text-white py-1 px-3 rounded inline-block">Cancelado</span>';
            }

            if ($order->payment_status == 'pending') {
                $estado_pago = '<span class="myorder_status-paid bg-yellow-500 text-white py-1 px-3 rounded inline-block">Pendiente</span>';
            }
            if ($order->payment_status == 'paid') {
                $estado_pago = '<span class="myorder_status-paid bg-green-700 text-white py-1 px-3 rounded inline-block">Pagado</span>';
            }
            if ($order->payment_status == 'failed') {
                $estado_pago = '<span class="myorder_status-paid bg-red-700 text-white py-1 px-3 rounded inline-block">Fallido</span>';
            }

        ?>
        <div class="detail_allcards001">
            <div class="detail_cardinfo">
                <div class="detail_cardinfo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </div>
                <div class="detail_cardinfo-text">
                    <p class="text_label">Usuario</p>
                    <div class=""><?php echo e($address->first_name); ?> <?php echo e($address->last_name); ?></div>
                </div>
            </div>
            <div class="detail_cardinfo">
                <div class="detail_cardinfo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                </div>
                <div class="detail_cardinfo-text">
                    <p class="text_label">Estado de Orden</p>
                    <div class=""><?php echo $estado; ?></div>
                </div>
            </div>
        </div>
        <div class="detail_allcards002">
            <div class="detail_cardinfo">
                <div class="detail_cardinfo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                </div>
                <div class="detail_cardinfo-text">
                    <p class="text_label">Fecha del Pedido</p>
                    <div class=""><?php echo e($order_items[0]->created_at->format('d-m-Y')); ?></div>
                </div>
            </div>
            <div class="detail_cardinfo">
                <div class="detail_cardinfo-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-receipt"><path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 17.5v-11"/></svg>
                </div>
                <div class="detail_cardinfo-text">
                    <p class="text_label">Estado de Pago</p>
                    <div class=""><?php echo $estado_pago; ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="detail_flex-container">
        <div class="detail_left">
          <div class="detail_card">
            <table class="detail_table">
              <thead>
                <tr>
                  <th class="detail_table-header">Producto</th>
                  <th class="detail_table-header">Precio</th>
                  <th class="detail_table-header">Cantidad</th>
                  <th class="detail_table-header">Total</th>
                </tr>
              </thead>
              <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr wire:key="<?php echo e($item->id); ?>">
                        <td class="detail_table-cell">
                        <div class="product_info">
                            <img class="product_image" src="<?php echo e(asset('storage/' . $item->product->image_path)); ?>" alt="Product image" width="100" height="100%">
                            <span><?php echo e($item->product->name); ?></span>
                        </div>
                        </td>
                        <td class="detail_table-cell">
                            <?php echo e(Number::currency($item->unit_amount, 'COP')); ?>

                        </td>
                        <td class="detail_table-cell">
                            <?php echo e($item->quantity); ?>

                        </td>
                        <td class="detail_table-cell">
                            <?php echo e(Number::currency($item->total_amount, 'COP')); ?>

                        </td>
                    </tr>       
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
              </tbody>
            </table>
        </div>
    
        <div class="detail_card">
            <h1 class="detail_section-title">Dirección de Envío</h1>
            <div class="detail_flex-between">
                <p><?php echo e($address->street_address); ?>, <?php echo e($address->city); ?>, <?php echo e($address->state); ?>, <?php echo e($address->zip_code); ?></p>
              <p><strong>Teléfono:</strong> <?php echo e($address->phone); ?></p>
            </div>
          </div>
        </div>
        <div class="detail_right">
          <div class="detail_card">
            <h2 class="detail_section-title">Resumen</h2>
            <div class="detail_summary-item">
              <span>Subtotal</span>
              <span><?php echo e(Number::currency($item->order->grand_total, 'COP')); ?></span>
            </div>
            <div class="detail_summary-item">
              <span>Envío</span>
              <span>COP 0.00</span>
            </div>
            <hr class="detail_divider">
            <div class="detail_summary-item">
              <span class="font-semibold">Total</span>
              <span class="font-semibold"><?php echo e(Number::currency($item->order->grand_total, 'COP')); ?></span>
            </div>
          </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Ecommerce_V2\resources\views/livewire/my-order-detail-page.blade.php ENDPATH**/ ?>