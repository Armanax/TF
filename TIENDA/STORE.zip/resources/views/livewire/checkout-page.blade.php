<div class="checkout_all">
    <h1 class="checkout_title">Pagar</h1>
    <form wire:submit.prevent='placeOrder'>
      <div class="checkout_container">
        <div class="checkout_left">
          <!-- Card -->
          <div class="checkout_card">
            <!-- Dirección de Envío -->
            <div class="checkout_section">
              <h2 class="checkout_section_title">Dirección de Envío</h2>
              <div class="checkout_input_group">
                <div>
                  <label for="first_name" class="checkout_label">Nombre</label>
                  <input wire:model='first_name' class="checkout_input @error('first_name') checkout_input_error @enderror" id="first_name" type="text">
                  @error('first_name')
                  <div class="checkout_error_message">{{ $message }}</div>
                  @enderror
                </div>
                <div>
                  <label for="last_name" class="checkout_label">Apellido</label>
                  <input wire:model='last_name' class="checkout_input @error('last_name') checkout_input_error @enderror" id="last_name" type="text">
                  @error('last_name')
                  <div class="checkout_error_message">{{ $message }}</div>
                  @enderror
                </div>
              </div>
              <div class="checkout_input_group">
                <label for="phone" class="checkout_label">Teléfono</label>
                <input wire:model='phone' class="checkout_input @error('phone') checkout_input_error @enderror" id="phone" type="text">
                @error('phone')
                <div class="checkout_error_message">{{ $message }}</div>
                @enderror
              </div>
              <div class="checkout_input_group">
                <label for="address" class="checkout_label">Dirección</label>
                <input wire:model='street_address' class="checkout_input @error('street_address') checkout_input_error @enderror" id="address" type="text">
                @error('street_address')
                <div class="checkout_error_message">{{ $message }}</div>
                @enderror
              </div>
              <div class="checkout_input_group">
                <label for="city" class="checkout_label">Ciudad</label>
                <input wire:model='city' class="checkout_input @error('city') checkout_input_error @enderror" id="city" type="text">
                @error('city')
                <div class="checkout_error_message">{{ $message }}</div>
                @enderror
              </div>
              <div class="checkout_input_group">
                <div>
                  <label for="state" class="checkout_label">Departamento</label>
                  <input wire:model='state' class="checkout_input @error('state') checkout_input_error @enderror" id="state" type="text">
                  @error('state')
                  <div class="checkout_error_message">{{ $message }}</div>
                  @enderror
                </div>
                <div>
                  <label for="zip" class="checkout_label">Código Postal</label>
                  <input wire:model='zip_code' class="checkout_input @error('zip_code') checkout_input_error @enderror" id="zip" type="text">
                  @error('zip_code')
                  <div class="checkout_error_message">{{ $message }}</div>
                  @enderror
                </div>
              </div>
            </div>
            <div class="checkout_payment_section">
              <div class="checkout_section_title">Seleccione el Método de Pago</div>
              <ul class="checkout_payment_methods">
                <li>
                  <input wire:model='payment_method' class="checkout_payment_radio" id="stripe" type="radio" value="stripe">
                  <label class="checkout_payment_label" for="stripe">
                    <div class="checkout_payment_name">Stripe</div>
                    <svg class="checkout_payment_icon" aria-hidden="true" viewbox="0 0 14 10">
                      <path d="M1 5h12m0 0L9 1m4 4L9 9" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path>
                    </svg>
                  </label>
                </li>
              </ul>
              @error('payment_method')
              <div class="checkout_error_message">{{ $message }}</div>
              @enderror
            </div>
          </div>
        </div>
        <div class="checkout_right">
          <div class="checkout_card">
            <div class="checkout_section_title">Resumen del Pedido</div>
            <div class="checkout_summary_item">
              <span>Subtotal</span>
              <span>{{ Number::currency($grand_total, 'COP') }}</span>
            </div>
            <div class="checkout_summary_item">
              <span>Costo de Envío</span>
              <span>{{ Number::currency(0, 'COP') }}</span>
            </div>
            <hr class="checkout_divider">
            <div class="checkout_summary_item">
              <span>Total</span>
              <span>{{ Number::currency($grand_total, 'COP') }}</span>
            </div>
          </div>
          <button class="checkout_button">
            <span wire:loading.remove>Realizar Pedido</span>
            <span wire:loading>Procesando...</span>
          </button>
          <div class="checkout_card">
            <div class="checkout_section_title">Resumen del Carrito</div>
            <ul class="checkout_cart_list">
              @foreach ($cart_items as $ci)
                <li class="checkout_cart_item" wire:key='{{ $ci['product_id'] }}'>
                  <div class="checkout_cart_item_info">
                    <img alt="{{ $ci['name'] }}" class="checkout_cart_item_image" src="{{ $ci['image'] }}">
                    <div>
                      <p class="checkout_cart_item_name">{{ $ci['name'] }}</p>
                      <p class="checkout_cart_item_quantity">Cantidad: {{ $ci['quantity'] }}</p>
                    </div>
                    <div class="checkout_cart_item_price">
                      {{ Number::currency($ci['total_amount'], 'COP') }}
                    </div>
                  </div>
                </li>
              @endforeach
            </ul>
          </div>
        </div>
      </div>
    </form>
  </div>
  