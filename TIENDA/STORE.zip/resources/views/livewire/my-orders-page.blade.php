<div class="myorder_all">
    <h1 class="myorder_titlepage">Mis Ordenes</h1>
    <div class="myorder_allitems">
        <div class="myorder_itemlist">
            <div class="myorder_items">
                <table class="myorder_table">
                    <thead>
                        <tr>
                            <th class="myorder_table_header">Orden</th>
                            <th class="myorder_table_header">Fecha</th>
                            <th class="myorder_table_header">Estado de Orden</th>
                            <th class="myorder_table_header">Estado de Pago</th>
                            <th class="myorder_table_header">Total de Pago</th>
                            <th class="myorder_table_header">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orders as $order)
                            @php
                                $status = '';
                                $payment_status= '';

                                if ($order->status == 'pending') {
                                    $status = '<span class="myorder_status-pending bg-blue-500 text-white py-1 px-3 rounded inline-block">Nuevo</span>';
                                }
                                if ($order->status == 'processing') {
                                    $status = '<span class="myorder_status-pending bg-yellow-500 text-white py-1 px-3 rounded inline-block">Procesando</span>';
                                }
                                if ($order->status == 'completed') {
                                    $status = '<span class="myorder_status-pending bg-green-500 text-white py-1 px-3 rounded inline-block">Enviado</span>';
                                }
                                if ($order->status == 'declined') {
                                    $status = '<span class="myorder_status-pending bg-green-700 text-white py-1 px-3 rounded inline-block">Rechazado</span>';
                                }
                                if ($order->status == 'canceled') {
                                    $status = '<span class="myorder_status-pending bg-red-700 text-white py-1 px-3 rounded inline-block">Cancelado</span>';
                                }


                                if ($order->payment_status == 'pending') {
                                    $payment_status = '<span class="myorder_status-paid bg-yellow-500 text-white py-1 px-3 rounded inline-block">Pendiente</span>';
                                }
                                if ($order->payment_status == 'paid') {
                                    $payment_status = '<span class="myorder_status-paid bg-green-700 text-white py-1 px-3 rounded inline-block">Pagado</span>';
                                }
                                if ($order->payment_status == 'failed') {
                                    $payment_status = '<span class="myorder_status-paid bg-red-700 text-white py-1 px-3 rounded inline-block">Fallido</span>';
                                }

                                
                            @endphp
                            <tr wire:key='{{$order->id}}'>
                                <td class="myorder_table_cell">{{$order->id}}</td>
                                <td class="myorder_table_cell">{{$order->created_at->format('d-m-Y')}}</td>
                                <td class="myorder_table_cell">{!! $status !!}</td>
                                <td class="myorder_table_cell">{!! $payment_status !!}</span></td>
                                <td class="myorder_table_cell">{{Number::currency($order->grand_total, 'COP')}}</td>
                                <td class="myorder_table_cell"><a href="/my-orders/{{$order->id}}" class="myorder_action-link">Ver Detalles</a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
        <div class="pagination mt-4">
            {{$orders->links()}}
        </div>
    </div>
</div>