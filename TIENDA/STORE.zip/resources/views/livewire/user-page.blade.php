<div class="profile_edit_all">
    <div class="profile_edit_container">
      <h1 class="profile_edit_title">Editar Perfil</h1>
      
      
      <hr class="profile_edit_hr">
  
      <form class="profile_edit_form" wire:submit.prevent='updateProfile'>
        @if (session('success'))
          <div class="profile_edit_alert" role="alert">
            {{ session('success') }}
          </div>
        @endif
        @if (session('error'))
          <div class="profile_edit_alert" role="alert">
            {{ session('error') }}
          </div>
        @endif
  
        <div class="profile_edit_input-group">
          <label for="name" class="profile_edit_label">Nombre</label>
          <input type="text" id="name" class="profile_edit_input" wire:model="name" aria-describedby="name-error">
          @error('name')
            <p class="text-xs text-red-600 mt-2" id="name-error">{{ $message }}</p>
          @enderror
        </div>
  
        <div class="profile_edit_input-group">
          <label for="email" class="profile_edit_label">Correo electrónico</label>
          <input type="email" id="email" class="profile_edit_input" wire:model="email" aria-describedby="email-error">         
          @error('email')
            <p class="text-xs text-red-600 mt-2" id="email-error">{{ $message }}</p>
          @enderror
        </div>
  
        <div class="profile_edit_input-group">
          <label for="password" class="profile_edit_label">Nueva Contraseña</label>
          <input type="password" id="password" class="profile_edit_input" wire:model="password" aria-describedby="password-error">
          @error('password')
            <p class="text-xs text-red-600 mt-2" id="password-error">{{ $message }}</p>
          @enderror
        </div>
  
        <div class="profile_edit_input-group">
          <label for="password_confirmation" class="profile_edit_label">Confirmar Contraseña</label>
          <input type="password" id="password_confirmation" class="profile_edit_input" wire:model="password_confirmation" aria-describedby="password_confirmation-error">
          @error('password_confirmation')
            <p class="text-xs text-red-600 mt-2" id="password_confirmation-error">{{ $message }}</p>
          @enderror
        </div>
  
        <button type="submit" class="profile_edit_button">Guardar Cambios</button>
      </form>
    </div>
  </div>
  
 
  