<header class="navbar_all">
    <div class="navbar_barDesktop">
        <div class="navbar_FirstMenu">
            <div class="navbar_Logo">
                <div class="navbar_name">
                    <a class="navbar_MenuLink" href="/">
                        <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                viewBox="0 0 490 80" style="enable-background:new 0 0 490 80;" xml:space="preserve">
                            <style type="text/css">
                                .st0{fill:#E9C500;}
                            </style>
                            <path class="st0" d="M14.3,0h461.4c7.9,0,14.3,6.4,14.3,14.3v51.4c0,7.9-6.4,14.3-14.3,14.3H14.3C6.4,80,0,73.6,0,65.7V14.3
                                C0,6.4,6.4,0,14.3,0z"/>
                            <g>
                                <path d="M14.1,14.1h29.5c0.2,0.1,0.3,0.1,0.3,0.3v14.3c0,0.2-0.1,0.3-0.3,0.3H19v20.3h9.8V37.7c0-0.2,0.1-0.3,0.3-0.3h14.5
                                    c0.2,0,0.3,0.1,0.3,0.3v26.1c-0.1,0.3-0.4,0.5-0.9,0.5H14.1c-3.9-3.8-7.2-7.1-10.1-10V24.2C7.8,20.3,11.2,17,14.1,14.1L14.1,14.1z"
                                    />
                                <path d="M82.7,14.3c0.3,0,1.1,5.2,2.1,15.7c0.1,0.2,1.6,11.5,4.3,34l-0.3,0.1H74.4c-0.4,0-1-4.3-1.8-13c-0.1,0-0.2-0.5-0.3-1.5H64
                                    c-1,8.9-1.6,13.8-1.8,14.5H47.7c-0.2,0-0.3-0.1-0.3-0.3c3.7-30.5,5.7-47,6.1-49.6L82.7,14.3L82.7,14.3z M66.6,29.1l-0.8,5.8h4.6
                                    l-0.6-5.8C69.8,29.1,66.6,29.1,66.6,29.1z"/>
                                <path d="M92.9,14.3h14.3c0.6,0.7,2.3,3.7,5,9.1l5.2,9.3c4.4-8.4,7.8-14.6,9.9-18.5h14.5c0.2,0,0.3,0.1,0.3,0.3v49.3
                                    c0,0.2-0.1,0.3-0.3,0.3h-14.3c-0.2,0-0.3-0.1-0.3-0.3V46.1H127c-2.7,5.4-4.3,8.4-4.9,8.8h-9.6c-0.8-0.9-2.4-3.8-4.9-8.8h-0.1v17.8
                                    c0,0.2-0.1,0.3-0.3,0.3H92.9c-0.2,0-0.3-0.1-0.3-0.3V14.6C92.6,14.4,92.7,14.3,92.9,14.3L92.9,14.3z"/>
                                <path d="M146,14.3h35.1c0.2,0,0.3,0.1,0.3,0.3v14.2c0,0.2-0.1,0.3-0.3,0.3h-20.6v2.7h11.4c0.2,0,0.3,0.1,0.3,0.3v14.2
                                    c0,0.2-0.1,0.3-0.3,0.3h-11.4v2.6h20.6c0.2,0,0.3,0.1,0.3,0.3v14.3c0,0.2-0.1,0.3-0.3,0.3H146c-0.2,0-0.3-0.1-0.3-0.3V14.6
                                    C145.7,14.4,145.8,14.3,146,14.3z"/>
                                <path d="M212.7,14.1h26.1c0.2,0.1,0.3,0.1,0.3,0.3v14.3c0,0.2-0.1,0.3-0.3,0.3h-21.2v20.3h21.2c0.2,0,0.3,0.1,0.3,0.3v14.2
                                    c0,0.2-0.1,0.3-0.3,0.3h-26.1c-3.7-3.5-7-6.8-9.9-9.9V24.1C206.3,20.4,209.6,17.1,212.7,14.1L212.7,14.1z"/>
                                <path d="M242.9,14.3H278c0.2,0,0.3,0.1,0.3,0.3v14.2c0,0.2-0.1,0.3-0.3,0.3h-20.6v2.7h11.4c0.2,0,0.3,0.1,0.3,0.3v14.2
                                    c0,0.2-0.1,0.3-0.3,0.3h-11.4v2.6H278c0.2,0,0.3,0.1,0.3,0.3v14.3c0,0.2-0.1,0.3-0.3,0.3h-35.1c-0.2,0-0.3-0.1-0.3-0.3V14.6
                                    C242.6,14.4,242.7,14.3,242.9,14.3z"/>
                                <path d="M282.1,14.3h14.3c0.4,0.3,3.7,6.4,9.9,18.3h0.1v-18c0-0.2,0.1-0.3,0.3-0.3H321c0.2,0,0.3,0.1,0.3,0.3v49.3
                                    c0,0.2-0.1,0.3-0.3,0.3h-14.3c-1.4-2.2-4.7-8.3-9.7-18.1h-0.2v17.8c0,0.2-0.1,0.3-0.3,0.3h-14.3c-0.2,0-0.3-0.1-0.3-0.3V14.6
                                    C281.8,14.4,281.9,14.3,282.1,14.3L282.1,14.3z"/>
                                <path d="M325.2,14.3h38.9c0.2,0,0.3,0.1,0.3,0.3v14.2c0,0.2-0.1,0.3-0.3,0.3H352v34.8c0,0.2-0.1,0.3-0.3,0.3h-14.2
                                    c-0.2,0-0.3-0.1-0.3-0.3V29.1h-12.1c-0.2,0-0.3-0.1-0.3-0.3V14.6C324.9,14.4,325,14.3,325.2,14.3L325.2,14.3z"/>
                                <path d="M368.2,14.1h30.2c2.7,2.6,5.7,5.6,9,9v17.3l-3.2,3.3l3.1,3.2v16.9c0,0.2-0.1,0.3-0.3,0.3h-14.2c-0.2,0-0.3-0.1-0.3-0.3
                                    V49.5h-9.6v14.3c0,0.2-0.1,0.3-0.3,0.3h-14.3c-0.2,0-0.3-0.1-0.3-0.3V14.4C367.9,14.2,368,14.1,368.2,14.1L368.2,14.1z M382.9,29.1
                                    v5.5h9.8v-5.5H382.9z"/>
                                <path d="M446.2,14.3c0.4,0,1,5.2,2.1,15.7c0.1,0.2,1.5,11.5,4.3,34l-0.3,0.1h-14.3c-0.4,0-1-4.3-1.8-13c-0.1,0-0.2-0.5-0.3-1.5
                                    h-8.3c-1,8.9-1.6,13.8-1.8,14.5h-14.5c-0.2,0-0.3-0.1-0.3-0.3c3.7-30.5,5.7-47,6.1-49.6L446.2,14.3L446.2,14.3z M430.2,29.1
                                    l-0.8,5.8h4.6l-0.6-5.8H430.2z"/>
                                <path d="M456.4,14.3h14.2c0.2,0,0.3,0.1,0.3,0.3v34.8h15.3c0.2,0,0.3,0.1,0.3,0.3v14.2c0,0.2-0.1,0.3-0.3,0.3h-29.7
                                    c-0.2,0-0.3-0.1-0.3-0.3V14.6C456.2,14.4,456.3,14.3,456.4,14.3L456.4,14.3z"/>
                            </g>
                        </svg>     
                    </a>
                </div>
                <div class="navbar_svgContainer">
                    <a class="navbar_MenuLink" href="/">
                        <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                viewBox="0 0 283 182.5" style="enable-background:new 0 0 283 182.5;" xml:space="preserve">
                            <style type="text/css">
                                .st0{fill:#E9C500;}
                                .st1{fill:none;stroke:#000000;stroke-miterlimit:10;}
                            </style>
                            <path class="st0" d="M25.6,11.5h232.7c7.3,0,13.1,5.9,13.1,13.1v131.7c0,7.3-5.9,13.1-13.1,13.1H25.6c-7.3,0-13.1-5.9-13.1-13.1
                                V24.6C12.5,17.4,18.4,11.5,25.6,11.5z"/>
                            <g>
                                <path d="M49.7,16.7h92.8c0.7,0.1,1,0.4,1,0.9v41.2c0,0.6-0.3,0.9-1,0.9H65V118h30.8V84.3c0.2-0.6,0.5-0.9,1-0.9h45.6
                                    c0.7,0.1,1,0.4,1,0.9v74.9c-0.3,0.9-1.3,1.3-2.9,1.3H49.7C37.4,149.7,26.8,140,18,131.6V45.7C29.9,34.4,40.4,24.8,49.7,16.7z"/>
                                <path d="M49.7,16.7h92.8c0.7,0.1,1,0.4,1,0.9v41.2c0,0.6-0.3,0.9-1,0.9H65V118h30.8V84.3c0.2-0.6,0.5-0.9,1-0.9h45.6
                                    c0.7,0.1,1,0.4,1,0.9v74.9c-0.3,0.9-1.3,1.3-2.9,1.3H49.7C37.4,149.7,26.8,140,18,131.6V45.7C29.9,34.4,40.4,24.8,49.7,16.7z"/>
                            </g>
                            <g>
                                <path d="M176.2,16.9h85.7c0.7,0.1,1,0.4,1,0.9v41.4c0,0.6-0.4,0.9-1,0.9h-69.7v58.5h69.7c0.7,0.1,1,0.4,1,0.9v40.9
                                    c0,0.6-0.4,0.9-1,0.9h-85.7c-12.1-10.2-23-19.8-32.7-28.6V45.5C155.2,34.9,166.1,25.4,176.2,16.9L176.2,16.9z"/>
                                <path d="M176.2,16.9h85.7c0.7,0.1,1,0.4,1,0.9v41.4c0,0.6-0.4,0.9-1,0.9h-69.7v58.5h69.7c0.7,0.1,1,0.4,1,0.9v40.9
                                    c0,0.6-0.4,0.9-1,0.9h-85.7c-12.1-10.2-23-19.8-32.7-28.6V45.5C155.2,34.9,166.1,25.4,176.2,16.9L176.2,16.9z"/>
                            </g>
                            <path class="st1" d="M12.8,0.5h257.5c6.8,0,12.2,5.5,12.2,12.2v157c0,6.8-5.5,12.2-12.2,12.2H12.8c-6.8,0-12.2-5.5-12.2-12.2v-157
                                C0.5,6,6,0.5,12.8,0.5z"/>
                        </svg>  
                    </a>
                </div>
            </div>
            <div class="navbar_BarraBusqueda">
                <input type="text" wire:model="search" id="searchInput" class="navbar_searchInput" placeholder="Busqueda...">
                <button wire:click="performSearch" id="searchButton" class="navbar_searchButton">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-search">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="m21 21-4.3-4.3"/>
                    </svg>
                </button>
            </div>          
            <div class="navbar_OptionsFirst">
                <div class="navbar_carrito">
                    <a class="navbar_linkCar" href="/cart">
                        <div class="navbar_logoCar">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                <path d="m15 11-1 9"/>
                                <path d="m19 11-4-7"/>
                                <path d="M2 11h20"/>
                                <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4"/>
                                <path d="M4.5 15.5h15"/>
                                <path d="m5 11 4-7"/>
                                <path d="m9 11 1 9"/>
                            </svg>
                        </div>
                        <div class="navbar_itemstotal">
                            <p>{{$total_count}}</p>
                        </div>
                    </a>
                </div>
                <div class="navbar_user">
                    @guest
                    <a class="navbar_linkUser" href="/login">
                        <div class="navbar_logoUser">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user">
                                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                        </div>
                        <div class="navbar_Announcement">
                            <p>LogIn</p>
                        </div>
                    </a>
                    @endguest
                    @auth
                        <div class="navbar_DropMenu hs-dropdown [--strategy:static] md:[--strategy:fixed] [--adaptive:none] md:[--trigger:hover]">
                            <button type="button" class="navbar_DropButton flex items-center w-full">
                                {{ auth()->user()->name }}
                            </button>
                            <div class="hs-dropdown-menu transition-[opacity,margin] duration-[0.1ms] md:duration-[150ms] hs-dropdown-open:opacity-100 opacity-0 md:w-48 hidden z-10 bg-[#383736] md:shadow-md rounded-lg p-2 before:absolute top-full md:border before:-top-5 before:start-0 before:w-full before:h-5">
                                <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" wire:navigate href="/my-orders">
                                    Mis Pedidos
                                </a>
                                <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="/userpage">
                                    Mi Cuenta
                                </a>
                                <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="/wishlist">
                                    Mi Lista de deseos
                                </a>
                                <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="/logout">
                                    Cerrar Sesión
                                </a>
                            </div>
                        </div>
                    @endauth
                </div>
            </div>
        </div>
        <div class="navbar_SecondMenu">
            <ul>
                <li><a href="/search">Buscador</a></li>
                <li><a href="/search?product_type=digital">Productos Digitales</a></li>
                <li><a href="/search?product_type=physical">Productos Fisicos</a></li>
                <li><a href="/search?product_type=ecard">Tarjetas de Regalo</a></li>
            </ul>
            <div class="md:hidden">
                <button type="button" class="hs-collapse-toggle p-2 inline-flex justify-center items-center gap-x-2 rounded-lg bg-transparent text-[#E9C500] shadow-sm hover:bg-gray-50 focus:outline-none dark:hover:bg-white/10"
                        data-hs-collapse="#mobile-menu" 
                        aria-controls="mobile-menu" 
                        aria-label="Toggle navigation" 
                        aria-expanded="false">
                    <svg class="hs-collapse-open:hidden w-6 h-6 fill-none stroke-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <line x1="3" x2="21" y1="6" y2="6"/>
                        <line x1="3" x2="21" y1="12" y2="12"/>
                        <line x1="3" x2="21" y1="18" y2="18"/>
                    </svg>
                    <svg class="hs-collapse-open:block hidden w-6 h-6 fill-none stroke-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M18 6 6 18"/>
                        <path d="M6 6l12 12"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <div id="mobile-menu" class="navbar_thirdMenu hs-collapse hidden overflow-hidden transition-all duration-300 bg-[#33302f] text-white md:hidden mt-2">
        <div class="py-2 border-t border-b border-gray-700">
            <!-- Menu Items -->
            <a href="/search" class="block py-3 px-4 hover:bg-gray-700">Buscador</a>
            <a href="#" class="block py-3 px-4 hover:bg-gray-700">Productos Digitales</a>
            <a href="#" class="block py-3 px-4 hover:bg-gray-700">Productos Fisicos</a>
            <a href="#" class="block py-3 px-4 hover:bg-gray-700">Tarjetas de Regalo</a>
    
            <!-- Shopping Cart Link -->
            <a href="/cart" class="flex items-center justify-start space-x-2 py-3 px-4 hover:bg-gray-700 w-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                    <path d="m15 11-1 9"/>
                    <path d="m19 11-4-7"/>
                    <path d="M2 11h20"/>
                    <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4"/>
                    <path d="M4.5 15.5h15"/>
                    <path d="m5 11 4-7"/>
                    <path d="m9 11 1 9"/>
                </svg>
                <span class="text-xs font-medium bg-[#E9C500] text-black py-0.5 px-1.5 rounded-full">{{$total_count}}</span>
            </a>
    
            <!-- Authentication Links -->
            @guest
            <a href="/login" class="flex items-center justify-start space-x-2 py-3 px-4 hover:bg-gray-700 w-full">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-6 w-6">
                    <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
                <span class="font-medium">Log In</span>
            </a>
            @endguest
    
            @auth
            <!-- User Dropdown for Authenticated Users -->
            <div class="hs-dropdown [--strategy:static] md:[--strategy:fixed] [--adaptive:none] md:[--trigger:hover] md:py-4">
                <button type="button" class="flex items-center justify-start space-x-2 py-3 px-4 hover:bg-gray-700 w-full text-white">
                    {{ auth()->user()->name }}
                    <svg class="ms-2 w-4 h-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m6 9 6 6 6-6" />
                    </svg>
                </button>
                <div class="hs-dropdown-menu transition-[opacity,margin] duration-[0.1ms] md:duration-[150ms] hs-dropdown-open:opacity-100 opacity-0 md:w-48 hidden z-10 md:shadow-md rounded-lg p-2 before:absolute top-full md:border before:-top-5 before:start-0 before:w-full before:h-5">
                    <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="/my-orders">
                        Mis Pedidos
                    </a>
                    <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="#">
                        Mi Cuenta
                    </a>
                    <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="#">
                        Mi Lista de deseos
                    </a>
                    <a class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-white hover:bg-[#E9C500] hover:text-black" href="/logout">
                        Cerrar Sesión
                    </a>
                </div>
            </div>
            @endauth
        </div>
    </div>
    
</header>
