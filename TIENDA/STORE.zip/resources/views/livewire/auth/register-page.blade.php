
<div class="register_all">
  <div class="register_container">
    <h1 class="register_title">Registrarse</h1>
    <p class="register_text">
      ¿Ya tienes una cuenta?
      <a href="/login" class="register_link">Inicia sesión aquí</a>
    </p>
    
    <hr class="register_hr">

    <form class="register_form" wire:submit.prevent='save'>
      <div class="register_input-group">
        <label for="name" class="register_label">Nombre</label>
        <div>
          <input type="text" id="name" class="register_input" wire:model="name" aria-describedby="name-error">
        </div>
        @error('name')
        <p class="text-xs text-red-600 mt-2" id="name-error">{{ $message }}</p>
        @enderror
      </div>

      <div class="register_input-group">
        <label for="email" class="register_label">Correo Electrónico</label>
        <div>
          <input type="email" id="email" class="register_input" wire:model="email" aria-describedby="email-error">
        </div>
        @error('email')
        <p class="text-xs text-red-600 mt-2" id="email-error">{{ $message }}</p>
        @enderror
      </div>

      <div class="register_input-group">
        <label for="password" class="register_label">Contraseña</label>
        <div>
          <input type="password" id="password" class="register_input" wire:model="password" aria-describedby="password-error">
        </div>
        @error('password')
        <p class="text-xs text-red-600 mt-2" id="password-error">{{ $message }}</p>
        @enderror
      </div>

      <button type="submit" class="register_button">Registrarse</button>
    </form>
  </div>
</div>
