<div class="reset_all">
  <div class="reset_container">
    <h1 class="reset_title">Restablecer contraseña</h1>

    <form class="reset_form" wire:submit.prevent='save'>
      <div class="reset_input-group">
        <label for="password" class="reset_label">Contraseña</label>
        <input type="password" id="password" class="reset_input" wire:model="password">
        @error('password')
          <p class="text-xs text-red-600 mt-2">{{ $message }}</p>
        @enderror
      </div>

      <div class="reset_input-group">
        <label for="password_confirmation" class="reset_label">Confirmar Contraseña</label>
        <input type="password" id="password_confirmation" class="reset_input" wire:model="password_confirmation">
        @error('password_confirmation')
          <p class="text-xs text-red-600 mt-2">{{ $message }}</p>
        @enderror
      </div>

      <button type="submit" class="reset_button">Guardar contraseña</button>
    </form>
  </div>
</div>
