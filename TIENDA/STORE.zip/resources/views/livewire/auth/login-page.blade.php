<div class="login_all">
  <div class="login_container">
    <h1 class="login_title">Iniciar sesión</h1>
    <p class="login_text">
      ¿No tienes una cuenta aún?
      <a href="/register" class="login_link">Regístrate aquí</a>
    </p>
    
    <hr class="login_hr">

    <form class="login_form" wire:submit.prevent='save'>
      @if (session('error'))
        <div class="login_alert" role="alert">
          {{ session('error') }}
        </div>
      @endif

      <div class="login_input-group">
        <label for="email" class="login_label">Correo electrónico</label>
        <input type="email" id="email" class="login_input" wire:model="email" aria-describedby="email-error">         
        @error('email')
          <p class="text-xs text-red-600 mt-2" id="email-error">{{ $message }}</p>
        @enderror
      </div>

      <div class="login_input-group">
        <label for="password" class="login_label">Contraseña</label>
        <div class="login_forgot-container">
          <input type="password" id="password" class="login_input" wire:model="password" aria-describedby="password-error">
          <a href="/forgot" class="login_forgot-link">¿Olvidaste tu contraseña?</a>
        </div>
        @error('password')
          <p class="text-xs text-red-600 mt-2" id="password-error">{{ $message }}</p>
        @enderror
      </div>

      <button type="submit" class="login_button">Iniciar sesión</button>
    </form>
  </div>
</div>
