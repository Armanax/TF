<div class="cart_all">
    <h1 class="cart_titlepage">Carrito de Compras</h1>
    <div class="cart_allitems">
        <div class="cart_itemlist">
            <div class="cart_items">
                <table class="cart_table">
                    <thead>
                        <tr>
                            <th class="cart_table_header">Producto</th>
                            <th class="cart_table_header">Precio</th>
                            <th class="cart_table_header">Cantidad</th>
                            <th class="cart_table_header">Total</th>
                            <th class="cart_table_header">Eliminar</th>
                        </tr>
                    </thead>
                    <tbody class="cart_itemCart">
                        @forelse ($items_carrito as $item)
                            <tr wire:key='{{$item['product_id']}}'>
                                <td class="cart_table_cell">
                                    <div class="cart_product">
                                        <img class="cart_product_image" src="{{$item['image']}}" alt="{{ $item['name']}}">
                                        <span class="cart_product_name">{{ $item['name']}}</span>
                                    </div>
                                </td>
                                <td class="cart_table_cell">
                                    {{ Number::currency($item['unit_amount'], 'COP')}}
                                </td>
                                <td class="cart_table_cell">
                                    <div class="cart_quantity">
                                        <button wire:click='ReducirItms({{ $item['product_id'] }})' class="cart_quantity_button">-</button>
                                        <span class="cart_quantity_text">{{ $item['quantity']}}</span>
                                        <button wire:click='AumentarItms({{ $item['product_id'] }})' class="cart_quantity_button">+</button>
                                    </div>
                                </td>
                                <td class="cart_table_cell">
                                    {{ Number::currency($item['unit_amount'], 'COP')}}
                                </td>
                                <td class="cart_table_cell">
                                    <button wire:click='quitarItem({{$item['product_id']}})' class="cart_remove_button">Eliminar</button>
                                </td>
                            </tr>
                            <div wire:key='{{$item['product_id']}}' class="mobile-cart-item">
                                <div class="mobile-cart-details">
                                    <span class="mobile-cart-name">{{ $item['name'] }}</span>
                                    <span class="mobile-cart-price">{{ Number::currency($item['unit_amount'], 'COP')}}</span>
                                </div>
                                <div class="mobile-cart-controls">
                                    <button wire:click='ReducirItms({{ $item['product_id'] }})' class="mobile-cart-quantity-button">-</button>
                                    <span class="mobile-cart-quantity-text">{{ $item['quantity']}}</span>
                                    <button wire:click='AumentarItms({{ $item['product_id'] }})' class="mobile-cart-quantity-button">+</button>
                                    <button wire:click='quitarItem({{$item['product_id']}})' class="mobile-cart-remove-button">Eliminar</button>
                                </div>
                            </div>
                            
                        @empty

                            <tr>
                                <td colspan="5" class="cart_empty_message">Tu carrito está vacío</td>
                            </tr>
                            <span class="cart_empty_message-movile">
                                <p class="cart_empty_message" >
                                    Tu carrito está vacío
                                </p>
                            </span>
                            
                        @endforelse
                        
                        
                    </tbody>
                </table>
            </div>
        </div>
        <div class="cart_totalprices">
            <h1>Resumen</h1>
            <div class="cart_allitemsPrices">
                <span class="cart_totalnumber">TOTAL</span><span>{{ Number::currency($total_final, 'COP')}}</span>
            </div>
            <hr class="cart_totalpricesSeparator">
            @if ($items_carrito)
                <button wire:click="checkout" class="cart_totalpricesCheakout">Pagar</button>
            @endif 
        </div>
    </div>
</div>
