<div class="wish_all">
    <h1 class="wish_titlepage">Lista de Deseos</h1>
    <div class="wish_expositor">
        @foreach ($wishlistItems as $item)
            <div class="homepage_cardProductDigital bg-[#333130] m-[1vh] w-[30%] h-[30vh]">
                <a href="#" class="homepage_linkCard flex flex-col w-full h-[90%]">
                    <div class="homepage_imgCardDigital flex w-full h-[55%]">
                        <img src="{{ asset('storage/' . $item->product->image_path) }}" alt="img" class="w-full h-full">
                    </div>
                    @if($item->product->product_type == 'digital')
                    <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                        <p class="mx-[5%]">{{ $item->product->region->name }}</p>-<p class="mx-[5%]">{{ $item->product->platform->name }}</p>
                    </span>
                    @else
                    <span class="homepage_regionDigial bg-[#222121] text-white flex justify-center items-center font-bold w-full h-[10%]">
                        <p class="mx-[5%]">{{ $item->product->label }}</p>
                    </span>
                    @endif
                    <div class="homepage_PricesDigital flex w-full h-[35%]">
                        @if($item->product->discount_percentage < 1)
                            <div class="homepage_allprices flex justify-center items-center w-full h-full">
                                <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-center">
                                    <p>${{ floor($item->product->discount_price) }}</p>
                                </span>
                            </div>
                        @else
                            <span class="homepage_discountDigital bg-red-600 text-black flex justify-center items-center font-extrabold text-[2rem] w-[30%] h-full">
                                {{ floor($item->product->discount_percentage) }}%
                            </span>
                            <div class="homepage_allprices flex flex-col justify-center items-center w-[70%] h-full">
                                <span class="homepage_realprice text-white line-through flex items-baseline w-full h-[30%]">
                                    <p>${{ floor($item->product->price) }}</p>
                                </span>
                                <span class="homepage_discountprice text-white font-bold text-[2rem] flex items-baseline w-full h-[70%]">
                                    <p>${{ floor($item->product->discount_price) }}</p>
                                </span>
                            </div>
                        @endif
                    </div>         
                </a>
                <div class="homepage_buttons flex justify-between w-full h-[10%]">
                    <button wire:click.prevent='addToCart({{$item->product->id}})'  class="homepage_shopBagDigital bg-[#222121] text-white flex items-center justify-center font-bold transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[65%]">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket"><path d="m15 11-1 9"/><path d="m19 11-4-7"/><path d="M2 11h20"/><path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4"/><path d="M4.5 15.5h15"/><path d="m5 11 4-7"/><path d="m9 11 1 9"/></svg>
                        <p>Comprar</p>
                    </button>
                    <button wire:click.prevent="toggleWishlist({{ $item->product->id }})" class="homepage_wishlistDigital bg-[#222121] text-white flex items-center justify-center transition-colors duration-300 transform hover:bg-[#383737] active:bg-[#1a1a1a] active:scale-[0.98] w-[34%]">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="{{ $this->isProductInWishlist($item->product->id) ? '#fff' : 'none' }}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star">
                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                        </svg>
                    </button> 
                </div>
            </div>
        @endforeach
    </div>  
    
</div>
