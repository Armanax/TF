<div class="ecard_all">
    <div class="ecard_allcontain">
        <h1 class="ecard_productname">{{ $product->name }}</h1>
        <div class="ecard_expositor001">
            <div class="ecard_carrusel">
                <!-- Slider -->
                <div class="flex flex-col w-full h-full" wire:ignore>
                    <div data-hs-carousel='{"loadingClasses": "opacity-0"}' class="relative w-full h-96">
                        <div class="hs-carousel relative overflow-hidden w-full h-full bg-white rounded-lg">
                            <div class="hs-carousel-body absolute top-0 bottom-0 start-0 flex flex-nowrap transition-transform duration-700 opacity-0 w-full h-full">
                                @foreach($product->images as $image)
                                    @if(isset($image['url']))
                                        <div class="hs-carousel-slide w-full h-full">
                                            <img src="{{ asset('storage/' . $image['url']) }}" alt="{{ $product->name }}" class="w-full h-full object-cover rounded-lg">
                                        </div>
                                    @else
                                        <div class="hs-carousel-slide w-full h-full">
                                            <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}" class="w-full h-full object-cover rounded-lg">
                                        </div>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                        <button type="button" class="hs-carousel-prev hs-carousel:disabled:opacity-50 disabled:pointer-events-none absolute inset-y-0 start-0 inline-flex justify-center items-center w-[46px] h-full text-gray-800 hover:bg-gray-800/10 rounded-s-lg dark:text-white dark:hover:bg-white/10">
                            <span class="text-2xl" aria-hidden="true">
                                <svg class="flex-shrink-0 size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m15 18-6-6 6-6"></path>
                                </svg>
                            </span>
                            <span class="sr-only">Previous</span>
                        </button>
                        <button type="button" class="hs-carousel-next hs-carousel:disabled:opacity-50 disabled:pointer-events-none absolute inset-y-0 end-0 inline-flex justify-center items-center w-[46px] h-full text-gray-800 hover:bg-gray-800/10 rounded-e-lg dark:text-white dark:hover:bg-white/10">
                            <span class="sr-only">Next</span>
                            <span class="text-2xl" aria-hidden="true">
                                <svg class="flex-shrink-0 size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m9 18 6-6-6-6"></path>
                                </svg>
                            </span>
                        </button>
                        <div class="hs-carousel-pagination flex justify-center absolute bottom-3 start-0 end-0 space-x-2">
                            @foreach($product->images as $index => $image)
                                @if(isset($image['url']))
                                    <span class="hs-carousel-active:bg-blue-700 hs-carousel-active:border-blue-700 size-3 border border-gray-400 rounded-full cursor-pointer dark:border-neutral-600 dark:hs-carousel-active:bg-blue-500 dark:hs-carousel-active:border-blue-500"></span>
                                @endif
                            @endforeach
                        </div>
                    </div>
                </div>
                <!-- End Slider -->
            </div>            
            <div class="ecard_principalcard">
                <div class="ecard_cardinfo">
                    <div class="ecard_cardinfo-company">
                        <h2>Compañía</h2>
                        <div class="ecard_cardinfo-companycont">
                            <span class="ecard_cardinfo-span">{{ $product->company->name }}</span>
                        </div>
                    </div> 
                    <div class="ecard_cardinfo-extrainfo">
                        <div class="ecard_cardinfo-extrainfo1">
                            <span class="ecard_cardinfo-extrainfoReg">{{ $product->ecardUse->name }}</span>
                        </div>
                        <div class="ecard_cardinfo-extrainfo2">
                            <div class="ecard_cardinfo-extrainfo2_1">
                                <span class="ecard_cardinfo-extrainfo01">Fecha de Lanzamiento:</span>
                                <span class="ecard_cardinfo-extrainfo01">{{ $product->release_date}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="ecard_cardinfo-price">
                        @if($product->discount_percentage > 0)
                            <div class="ecard_cardinfo-price001">
                                <span class="ecard_cardinfo-pricepercen">{{ round($product->discount_percentage) }}%</span>
                                <span class="ecard_cardinfo-pricenormal">${{ number_format($product->price, 2) }}</span>
                            </div>
                        @endif
                        <div class="ecard_cardinfo-price002">
                            <span class="ecard_cardinfo-pricediscount">
                                @if($product->discount_percentage > 0)
                                    ${{ number_format($product->discount_price, 2) }}
                                @else
                                    ${{ number_format($product->price, 2) }}
                                @endif
                            </span>
                        </div>
                    </div>
                    <div class="ecard_cardinfo-buttons">
                        <button class="physical_cardinfo-buttonsbuy" wire:click.prevent='addToCart({{$product->id}})'>
                            <span class="button-content">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shopping-basket">
                                    <path d="m15 11-1 9"/>
                                    <path d="m19 11-4-7"/>
                                    <path d="M2 11h20"/>
                                    <path d="m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4"/>
                                    <path d="M4.5 15.5h15"/>
                                    <path d="m5 11 4-7"/>
                                    <path d="m9 11 1 9"/>
                                </svg>
                                <p wire:loading.remove wire:target='addToCart'>Comprar</p>
                                <p wire:loading wire:target='addToCart'>Agregando...</p>
                            </span>
                        </button>
                        <button class="digi_cardinfo-buttonswish" wire:click.prevent="toggleWishlist({{ $product->id }})">
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="{{ $this->isProductInWishlist($product->id) ? '#000' : 'none' }}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star" wire:loading.remove wire:target="toggleWishlist">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                                </svg>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle animate-spin" wire:loading wire:target="toggleWishlist">
                                    <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                                </svg>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="ecard_expositor002">
            <div class="ecard_description">
                <h2 class="ecard_description-title">Descripción</h2>
                <p>{{ $product->description }}</p>
            </div>
        </div>
    </div>
</div>
