<x-mail::message>
# Alerta de Descuentos

¡Gran noticia! Los siguientes productos están ahora disponibles a precios más bajos:

<x-mail::table>
| Producto       | Precio Original | Descuento | Precio con Descuento |
| -------------- | ---------------:| ---------:| --------------------:|
@foreach($products as $product)
| {{ $product->name }} | ${{ number_format($product->price, 2) }} | {{ $product->discount_percentage }}% | ${{ number_format($product->discount_price, 2) }} |
@endforeach
</x-mail::table>

<x-mail::button :url="url('/wishlist')">
Ver Todos los Productos
</x-mail::button>

Gracias por tu atención,<br>
{{ config('app.name') }}
</x-mail::message>
