<x-mail::message>
# Su orden se ha recibido correctamente

Gracias por su compra, nuestro equipo está verificando los datos. En caso de productos digitales, recibirá un correo con su compra. En caso de productos físicos, recibirá un correo con la confirmación de envío. Su número de orden es: {{ $order->id }}.

<x-mail::button :url="$url">
    Ver Orden
</x-mail::button>

Gracias,<br>
{{ config('app.name') }}
</x-mail::message>
