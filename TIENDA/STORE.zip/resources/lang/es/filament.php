<?php

return [
    'dashboard' => [
        'label' => 'Panel de control',
    ],

    'account' => [
        'label' => 'Cuenta',
        'logout' => 'Cerrar sesión',
    ],

    'widgets' => [
        'account' => [
            'welcome' => 'Bienvenido, :name',
            'admin' => 'Administrador',
        ],
        'filament' => [
            'documentation' => 'Documentación',
            'github' => 'GitHub',
        ],
    ],

    'login' => [
        'username' => 'Nombre de usuario',
        'password' => 'Contraseña',
        'button' => 'Iniciar sesión',
    ],

    // más traducciones según sea necesario...
];
